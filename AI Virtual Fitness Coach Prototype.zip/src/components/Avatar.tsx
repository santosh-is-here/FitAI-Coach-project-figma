import { CSSProperties, ReactElement } from 'react'

type AvatarMood = 'happy' | 'encouraging' | 'resting' | 'concerned' | 'celebrating'

interface AvatarProps {
  mood?: AvatarMood
  size?: number
  animate?: boolean
  style?: CSSProperties
}

export default function Avatar({ mood = 'happy', size = 120, animate = true, style }: AvatarProps) {
  const colors = {
    happy: { face: '#F5CBA7', ring: '#2196F3', glow: 'rgba(33,150,243,0.4)' },
    encouraging: { face: '#F5CBA7', ring: '#39FF14', glow: 'rgba(57,255,20,0.4)' },
    resting: { face: '#F5CBA7', ring: '#8B5CF6', glow: 'rgba(139,92,246,0.4)' },
    concerned: { face: '#F5CBA7', ring: '#F59E0B', glow: 'rgba(245,158,11,0.4)' },
    celebrating: { face: '#F5CBA7', ring: '#39FF14', glow: 'rgba(57,255,20,0.5)' },
  }

  const c = colors[mood]
  const s = size

  const expressions: Record<AvatarMood, ReactElement> = {
    happy: (
      <>
        <ellipse cx={s * 0.38} cy={s * 0.44} rx={s * 0.05} ry={s * 0.06} fill="#3D2314" />
        <ellipse cx={s * 0.62} cy={s * 0.44} rx={s * 0.05} ry={s * 0.06} fill="#3D2314" />
        <path d={`M${s*0.35} ${s*0.56} Q${s*0.5} ${s*0.66} ${s*0.65} ${s*0.56}`} stroke="#3D2314" strokeWidth={s*0.025} fill="none" strokeLinecap="round" />
      </>
    ),
    encouraging: (
      <>
        <ellipse cx={s * 0.38} cy={s * 0.44} rx={s * 0.05} ry={s * 0.07} fill="#3D2314" />
        <ellipse cx={s * 0.62} cy={s * 0.44} rx={s * 0.05} ry={s * 0.07} fill="#3D2314" />
        <path d={`M${s*0.33} ${s*0.55} Q${s*0.5} ${s*0.68} ${s*0.67} ${s*0.55}`} stroke="#3D2314" strokeWidth={s*0.025} fill="none" strokeLinecap="round" />
        <path d={`M${s*0.3} ${s*0.3} L${s*0.24} ${s*0.2}`} stroke="#3D2314" strokeWidth={s*0.02} strokeLinecap="round" />
        <path d={`M${s*0.7} ${s*0.3} L${s*0.76} ${s*0.2}`} stroke="#3D2314" strokeWidth={s*0.02} strokeLinecap="round" />
      </>
    ),
    resting: (
      <>
        <path d={`M${s*0.32} ${s*0.43} Q${s*0.38} ${s*0.41} ${s*0.44} ${s*0.43}`} stroke="#3D2314" strokeWidth={s*0.025} fill="none" strokeLinecap="round" />
        <path d={`M${s*0.56} ${s*0.43} Q${s*0.62} ${s*0.41} ${s*0.68} ${s*0.43}`} stroke="#3D2314" strokeWidth={s*0.025} fill="none" strokeLinecap="round" />
        <path d={`M${s*0.38} ${s*0.59} Q${s*0.5} ${s*0.62} ${s*0.62} ${s*0.59}`} stroke="#3D2314" strokeWidth={s*0.02} fill="none" strokeLinecap="round" />
      </>
    ),
    concerned: (
      <>
        <ellipse cx={s * 0.38} cy={s * 0.44} rx={s * 0.05} ry={s * 0.05} fill="#3D2314" />
        <ellipse cx={s * 0.62} cy={s * 0.44} rx={s * 0.05} ry={s * 0.05} fill="#3D2314" />
        <path d={`M${s*0.35} ${s*0.6} Q${s*0.5} ${s*0.54} ${s*0.65} ${s*0.6}`} stroke="#3D2314" strokeWidth={s*0.025} fill="none" strokeLinecap="round" />
        <path d={`M${s*0.32} ${s*0.37} L${s*0.44} ${s*0.33}`} stroke="#3D2314" strokeWidth={s*0.02} strokeLinecap="round" />
        <path d={`M${s*0.56} ${s*0.33} L${s*0.68} ${s*0.37}`} stroke="#3D2314" strokeWidth={s*0.02} strokeLinecap="round" />
      </>
    ),
    celebrating: (
      <>
        <path d={`M${s*0.32} ${s*0.43} Q${s*0.38} ${s*0.39} ${s*0.44} ${s*0.43}`} stroke="#3D2314" strokeWidth={s*0.025} fill="none" strokeLinecap="round" />
        <path d={`M${s*0.56} ${s*0.43} Q${s*0.62} ${s*0.39} ${s*0.68} ${s*0.43}`} stroke="#3D2314" strokeWidth={s*0.025} fill="none" strokeLinecap="round" />
        <path d={`M${s*0.32} ${s*0.54} Q${s*0.5} ${s*0.7} ${s*0.68} ${s*0.54}`} stroke="#3D2314" strokeWidth={s*0.025} fill="rgba(255,150,100,0.3)" strokeLinecap="round" />
        <circle cx={s*0.37} cy={s*0.57} r={s*0.03} fill="rgba(255,120,80,0.6)" />
        <circle cx={s*0.63} cy={s*0.57} r={s*0.03} fill="rgba(255,120,80,0.6)" />
      </>
    ),
  }

  return (
    <div style={{
      position: 'relative',
      width: s,
      height: s,
      ...(animate ? { animation: 'float 3s ease-in-out infinite' } : {}),
      ...style,
    }}>
      {/* Glow ring */}
      <div style={{
        position: 'absolute',
        inset: -8,
        borderRadius: '50%',
        background: `radial-gradient(circle, ${c.glow} 0%, transparent 70%)`,
        animation: 'pulse-ring 2.5s ease-out infinite',
      }} />

      <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} fill="none">
        {/* Outer ring */}
        <circle cx={s/2} cy={s/2} r={s/2 - 2} stroke={c.ring} strokeWidth={3} strokeDasharray="8 4" opacity={0.6} />
        {/* Body */}
        <circle cx={s/2} cy={s/2} r={s * 0.42} fill={`url(#av-body-${mood})`} />
        {/* Face circle */}
        <circle cx={s/2} cy={s * 0.48} r={s * 0.3} fill={c.face} />
        {/* Hair */}
        <ellipse cx={s/2} cy={s * 0.2} rx={s * 0.24} ry={s * 0.14} fill="#3D2314" />
        <ellipse cx={s * 0.35} cy={s * 0.24} rx={s * 0.06} ry={s * 0.1} fill="#3D2314" />
        <ellipse cx={s * 0.65} cy={s * 0.24} rx={s * 0.06} ry={s * 0.1} fill="#3D2314" />
        {/* Expression */}
        {expressions[mood]}
        {/* AI indicator */}
        <circle cx={s * 0.78} cy={s * 0.22} r={s * 0.1} fill={c.ring} />
        <text x={s * 0.78} y={s * 0.25} textAnchor="middle" fill="white" fontSize={s * 0.1} fontWeight="700">AI</text>
        <defs>
          <radialGradient id={`av-body-${mood}`} cx="40%" cy="35%" r="60%">
            <stop offset="0%" stopColor={c.ring} stopOpacity={0.8} />
            <stop offset="100%" stopColor="#0A0C1A" />
          </radialGradient>
        </defs>
      </svg>
    </div>
  )
}
