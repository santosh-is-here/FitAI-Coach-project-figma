import { useState, useEffect, useRef } from 'react'
import SplashScreen from './screens/SplashScreen'
import WelcomeScreen from './screens/WelcomeScreen'
import AssessmentScreen from './screens/AssessmentScreen'
import ReadinessScreen from './screens/ReadinessScreen'
import LiveWorkoutScreen from './screens/LiveWorkoutScreen'
import BreakScreen from './screens/BreakScreen'
import PainReportScreen from './screens/PainReportScreen'
import SafetyScreen from './screens/SafetyScreen'
import CoolDownScreen from './screens/CoolDownScreen'
import WorkoutCompletedScreen from './screens/WorkoutCompletedScreen'
import DashboardScreen from './screens/DashboardScreen'
import DesignSystemPage from './screens/DesignSystemPage'

export type Screen =
  | 'splash'
  | 'welcome'
  | 'assessment'
  | 'readiness'
  | 'live-workout'
  | 'break'
  | 'pain-report'
  | 'safety'
  | 'cool-down'
  | 'workout-completed'
  | 'dashboard'
  | 'design-system'

export default function App() {
  const [screen, setScreen] = useState<Screen>('splash')
  const [prevScreen, setPrevScreen] = useState<Screen | null>(null)
  const [animating, setAnimating] = useState(false)

  const navigate = (to: Screen) => {
    if (animating) return
    setAnimating(true)
    setPrevScreen(screen)
    setTimeout(() => {
      setScreen(to)
      setAnimating(false)
    }, 200)
  }

  const renderScreen = () => {
    switch (screen) {
      case 'splash': return <SplashScreen onNext={() => navigate('welcome')} />
      case 'welcome': return <WelcomeScreen onStart={() => navigate('assessment')} onDashboard={() => navigate('dashboard')} />
      case 'assessment': return <AssessmentScreen onComplete={() => navigate('readiness')} onBack={() => navigate('welcome')} />
      case 'readiness': return <ReadinessScreen onStart={() => navigate('live-workout')} onBack={() => navigate('assessment')} />
      case 'live-workout': return <LiveWorkoutScreen
        onBreak={() => navigate('break')}
        onPain={() => navigate('pain-report')}
        onComplete={() => navigate('cool-down')}
      />
      case 'break': return <BreakScreen onResume={() => navigate('live-workout')} onEnd={() => navigate('dashboard')} />
      case 'pain-report': return <PainReportScreen onSafety={() => navigate('safety')} onBack={() => navigate('live-workout')} />
      case 'safety': return <SafetyScreen onEnd={() => navigate('dashboard')} />
      case 'cool-down': return <CoolDownScreen onComplete={() => navigate('workout-completed')} />
      case 'workout-completed': return <WorkoutCompletedScreen onDone={() => navigate('dashboard')} />
      case 'dashboard': return <DashboardScreen onStartWorkout={() => navigate('welcome')} onDesignSystem={() => navigate('design-system')} />
      case 'design-system': return <DesignSystemPage onBack={() => navigate('dashboard')} />
    }
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(33,150,243,0.15) 0%, transparent 60%), #04050A',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'flex-start',
      padding: '24px 0 48px',
      gap: 24
    }}>
      {/* App header nav */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, paddingTop: 8 }}>
        <div style={{
          width: 32, height: 32,
          background: 'linear-gradient(135deg, #2196F3, #39FF14)',
          borderRadius: 10,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 16
        }}>⚡</div>
        <span style={{ color: '#F0F4FF', fontWeight: 800, fontSize: 18, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>FitAI Coach</span>
        <span style={{ color: '#39FF14', fontSize: 11, fontWeight: 700, background: 'rgba(57,255,20,0.12)', padding: '2px 8px', borderRadius: 100, border: '1px solid rgba(57,255,20,0.25)' }}>PROTOTYPE</span>
      </div>

      {/* Screen nav pills */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, justifyContent: 'center', maxWidth: 800, padding: '0 16px' }}>
        {([
          ['splash', '1. Splash'],
          ['welcome', '2. Welcome'],
          ['assessment', '3. Assessment'],
          ['readiness', '4. Readiness'],
          ['live-workout', '5. Live Workout'],
          ['break', '6. Break'],
          ['pain-report', '7. Pain Report'],
          ['safety', '8. Safety'],
          ['cool-down', '9. Cool Down'],
          ['workout-completed', '10. Completed'],
          ['dashboard', '11. Dashboard'],
          ['design-system', '12. Design System'],
        ] as [Screen, string][]).map(([s, label]) => (
          <button key={s} onClick={() => navigate(s)} style={{
            padding: '6px 14px',
            borderRadius: 100,
            border: screen === s ? '1px solid #2196F3' : '1px solid rgba(255,255,255,0.1)',
            background: screen === s ? 'rgba(33,150,243,0.2)' : 'rgba(255,255,255,0.04)',
            color: screen === s ? '#93C5FD' : '#6B7DB8',
            fontSize: 12,
            fontWeight: 600,
            cursor: 'pointer',
            transition: 'all 0.15s ease',
            fontFamily: "'Plus Jakarta Sans', sans-serif",
          }}>
            {label}
          </button>
        ))}
      </div>

      {/* Mobile frame */}
      <div className="mobile-frame" style={{ opacity: animating ? 0 : 1, transition: 'opacity 0.2s ease' }}>
        {renderScreen()}
      </div>

      <p style={{ color: '#3A4A6B', fontSize: 12, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
        Use the nav above to jump between screens
      </p>
    </div>
  )
}
