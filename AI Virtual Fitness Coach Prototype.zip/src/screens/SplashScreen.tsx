import { useEffect, useState } from 'react'

export default function SplashScreen({ onNext }: { onNext: () => void }) {
  const [phase, setPhase] = useState(0)

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 400)
    const t2 = setTimeout(() => setPhase(2), 900)
    const t3 = setTimeout(() => setPhase(3), 1500)
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3) }
  }, [])

  return (
    <div style={{
      minHeight: 844,
      background: 'radial-gradient(ellipse 70% 50% at 50% 30%, rgba(33,150,243,0.25) 0%, transparent 70%), #080910',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '80px 32px 60px',
    }}>
      {/* Top badge */}
      <div style={{ opacity: phase >= 1 ? 1 : 0, transition: 'opacity 0.6s ease', display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#39FF14', animation: 'pulse-ring 2s ease infinite' }} />
        <span style={{ color: '#39FF14', fontSize: 11, fontWeight: 700, letterSpacing: '0.12em' }}>POWERED BY AI</span>
      </div>

      {/* Center content */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 32 }}>
        {/* Logo */}
        <div style={{
          opacity: phase >= 1 ? 1 : 0,
          transform: phase >= 1 ? 'scale(1)' : 'scale(0.7)',
          transition: 'all 0.7s cubic-bezier(0.34, 1.56, 0.64, 1)',
          position: 'relative',
        }}>
          {/* Outer glow rings */}
          {[1.4, 1.2, 1.0].map((scale, i) => (
            <div key={i} style={{
              position: 'absolute',
              inset: `${-(scale-1)*60}px`,
              borderRadius: '50%',
              border: `1px solid rgba(33,150,243,${0.15 - i*0.04})`,
              animation: `spin-slow ${8 + i*3}s linear infinite`,
              animationDirection: i % 2 ? 'reverse' : 'normal',
            }} />
          ))}

          <div style={{
            width: 120, height: 120,
            borderRadius: '32px',
            background: 'linear-gradient(135deg, #1565C0 0%, #2196F3 50%, #39FF14 100%)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 0 60px rgba(33,150,243,0.5), 0 0 100px rgba(57,255,20,0.2)',
            position: 'relative', zIndex: 1,
          }}>
            <span style={{ fontSize: 56 }}>⚡</span>
          </div>
        </div>

        <div style={{ textAlign: 'center', opacity: phase >= 2 ? 1 : 0, transition: 'opacity 0.6s ease 0.2s' }}>
          <h1 style={{ color: '#F0F4FF', fontSize: 38, fontWeight: 800, margin: 0, letterSpacing: '-0.02em', lineHeight: 1.1 }}>
            FitAI<br />
            <span style={{ background: 'linear-gradient(135deg, #2196F3, #39FF14)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              Coach
            </span>
          </h1>
          <p style={{ color: '#8B9CC8', fontSize: 15, margin: '12px 0 0', fontWeight: 500 }}>
            Your intelligent workout companion
          </p>
        </div>

        {/* Feature pills */}
        <div style={{
          display: 'flex', flexDirection: 'column', gap: 10,
          opacity: phase >= 3 ? 1 : 0, transition: 'opacity 0.6s ease',
          width: '100%',
        }}>
          {[
            { icon: '🧠', text: 'Real-time AI form guidance' },
            { icon: '🛡️', text: 'Safety-first exercise design' },
            { icon: '💪', text: 'Personalized for beginners' },
          ].map(({ icon, text }) => (
            <div key={text} className="glass" style={{ borderRadius: 14, padding: '12px 18px', display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ fontSize: 20 }}>{icon}</span>
              <span style={{ color: '#C4D4F0', fontSize: 14, fontWeight: 500 }}>{text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div style={{ width: '100%', opacity: phase >= 3 ? 1 : 0, transition: 'opacity 0.6s ease', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <button className="btn-accent animate-glow" onClick={onNext}>
          Get Started
        </button>
        <p style={{ color: '#3A4A6B', fontSize: 12, textAlign: 'center', margin: 0 }}>
          No equipment needed · Beginner friendly
        </p>
      </div>
    </div>
  )
}
