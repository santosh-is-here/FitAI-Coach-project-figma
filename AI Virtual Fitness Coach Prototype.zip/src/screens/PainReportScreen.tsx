import { useState } from 'react'

const bodyParts = [
  { id: 'Knee', icon: '🦵' },
  { id: 'Back', icon: '🔙' },
  { id: 'Shoulder', icon: '🫱' },
  { id: 'Neck', icon: '🦒' },
  { id: 'Chest', icon: '❤️' },
  { id: 'Other', icon: '🩹' },
]

const dangerous = ['Chest', 'Dizziness', 'Breathing']

export default function PainReportScreen({ onSafety, onBack }: { onSafety: () => void; onBack: () => void }) {
  const [selected, setSelected] = useState<string | null>(null)
  const [painScale, setPainScale] = useState(3)

  const isHighPain = painScale >= 7
  const isDangerous = selected === 'Chest'

  const handleContinue = () => {
    if (isHighPain || isDangerous) onSafety()
    else onBack()
  }

  return (
    <div style={{ minHeight: 844, background: '#080910', display: 'flex', flexDirection: 'column', padding: '24px 24px 48px' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
        <button onClick={onBack} style={{ width: 40, height: 40, borderRadius: 12, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)', color: '#8B9CC8', cursor: 'pointer', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>←</button>
        <div>
          <div style={{ color: '#F0F4FF', fontWeight: 700, fontSize: 18 }}>Pain Report</div>
          <div style={{ color: '#8B9CC8', fontSize: 13 }}>Your safety is our priority</div>
        </div>
      </div>

      {/* Warning card */}
      <div className="glass-red" style={{ borderRadius: 18, padding: '18px', marginBottom: 28 }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <span style={{ fontSize: 28 }}>🛑</span>
          <div>
            <div style={{ color: '#FCA5A5', fontWeight: 700, fontSize: 15 }}>Important</div>
            <p style={{ color: '#FCA5A5', fontSize: 13, margin: 0, opacity: 0.9, lineHeight: 1.4 }}>
              Answer honestly. I'll adjust your workout or recommend stopping if needed.
            </p>
          </div>
        </div>
      </div>

      {/* Body part selection */}
      <div style={{ marginBottom: 28 }}>
        <h3 style={{ color: '#F0F4FF', fontSize: 16, fontWeight: 700, margin: '0 0 14px' }}>
          Where are you feeling pain?
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
          {bodyParts.map(({ id, icon }) => (
            <button key={id} onClick={() => setSelected(id)} style={{
              padding: '18px 8px', borderRadius: 16,
              border: selected === id ? `2px solid ${id === 'Chest' ? '#EF4444' : '#F59E0B'}` : '1px solid rgba(255,255,255,0.08)',
              background: selected === id
                ? id === 'Chest' ? 'rgba(239,68,68,0.15)' : 'rgba(245,158,11,0.12)'
                : 'rgba(255,255,255,0.04)',
              cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
            }}>
              <span style={{ fontSize: 28 }}>{icon}</span>
              <span style={{
                color: selected === id ? (id === 'Chest' ? '#FCA5A5' : '#FCD34D') : '#8B9CC8',
                fontWeight: 600, fontSize: 12,
              }}>{id}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Pain scale */}
      {selected && (
        <div style={{ marginBottom: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h3 style={{ color: '#F0F4FF', fontSize: 16, fontWeight: 700, margin: 0 }}>Pain Intensity</h3>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
              <span style={{ color: painScale >= 7 ? '#EF4444' : '#F59E0B', fontSize: 32, fontWeight: 800, fontFamily: "'Space Mono', monospace" }}>{painScale}</span>
              <span style={{ color: '#8B9CC8', fontSize: 14 }}>/10</span>
            </div>
          </div>

          <div style={{ position: 'relative', height: 48, display: 'flex', alignItems: 'center', marginBottom: 8 }}>
            <div style={{ width: '100%', height: 8, borderRadius: 4, background: 'rgba(255,255,255,0.06)' }}>
              <div style={{
                height: '100%', borderRadius: 4,
                width: `${(painScale - 1) / 9 * 100}%`,
                background: painScale >= 7
                  ? 'linear-gradient(90deg, #F59E0B, #EF4444)'
                  : 'linear-gradient(90deg, #39FF14, #F59E0B)',
                transition: 'all 0.15s ease',
              }} />
            </div>
            <input type="range" min={1} max={10} value={painScale}
              onChange={e => setPainScale(Number(e.target.value))}
              style={{ position: 'absolute', inset: 0, opacity: 0, cursor: 'pointer', width: '100%' }}
            />
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ color: '#8B9CC8', fontSize: 12 }}>1 - Minimal</span>
            <span style={{ color: '#8B9CC8', fontSize: 12 }}>10 - Severe</span>
          </div>

          {/* High pain warning */}
          {isHighPain && (
            <div style={{ marginTop: 16, background: 'rgba(239,68,68,0.15)', borderRadius: 16, padding: '16px', border: '2px solid rgba(239,68,68,0.4)', animation: 'fade-in 0.3s ease' }}>
              <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                <span style={{ fontSize: 24 }}>⚠️</span>
                <div>
                  <div style={{ color: '#FCA5A5', fontWeight: 700, fontSize: 15, marginBottom: 4 }}>High Pain Detected</div>
                  <p style={{ color: '#FCA5A5', fontSize: 13, margin: 0, lineHeight: 1.5 }}>
                    Pain at this level requires medical attention. Please stop exercising immediately.
                  </p>
                </div>
              </div>
            </div>
          )}

          {selected === 'Chest' && (
            <div style={{ marginTop: 12, background: 'rgba(239,68,68,0.2)', borderRadius: 16, padding: '16px', border: '2px solid rgba(239,68,68,0.5)' }}>
              <div style={{ color: '#EF4444', fontWeight: 800, fontSize: 15, marginBottom: 4 }}>⛑️ Chest Pain Warning</div>
              <p style={{ color: '#FCA5A5', fontSize: 13, margin: 0, lineHeight: 1.5 }}>
                Chest pain during exercise requires immediate attention. Please stop and seek medical help.
              </p>
            </div>
          )}
        </div>
      )}

      <div style={{ marginTop: 'auto', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {selected && (isHighPain || isDangerous) ? (
          <button className="btn-danger" onClick={handleContinue}>
            ⛑️ Get Safety Guidance
          </button>
        ) : selected ? (
          <>
            <button className="btn-primary" onClick={onBack}>
              Modify Workout & Continue
            </button>
            <button className="btn-ghost" onClick={onBack}>
              Return to Workout
            </button>
          </>
        ) : (
          <button className="btn-ghost" onClick={onBack}>
            Cancel — Return to Workout
          </button>
        )}
      </div>
    </div>
  )
}
