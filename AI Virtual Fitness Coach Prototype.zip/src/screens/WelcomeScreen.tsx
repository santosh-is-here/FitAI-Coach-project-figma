import Avatar from '../components/Avatar'

export default function WelcomeScreen({ onStart, onDashboard }: { onStart: () => void; onDashboard: () => void }) {
  const stats = [
    { value: '20', unit: 'min', label: "Today's workout" },
    { value: '10', unit: 'ex', label: 'Exercises' },
    { value: '0', unit: 'eq', label: 'Equipment' },
  ]

  return (
    <div style={{
      minHeight: 844,
      background: 'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(33,150,243,0.2) 0%, transparent 55%), #080910',
      display: 'flex', flexDirection: 'column',
      padding: '0 0 40px',
    }}>
      {/* Status bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '16px 24px 0', alignItems: 'center' }}>
        <span style={{ color: '#8B9CC8', fontSize: 13, fontFamily: "'Space Mono', monospace" }}>9:41</span>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <div style={{ width: 16, height: 10, border: '1.5px solid #8B9CC8', borderRadius: 3, position: 'relative' }}>
            <div style={{ position: 'absolute', left: 2, top: 2, bottom: 2, width: '65%', background: '#39FF14', borderRadius: 1 }} />
          </div>
          <span style={{ color: '#8B9CC8', fontSize: 12 }}>📶</span>
        </div>
      </div>

      {/* Hero section */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '24px 24px 0', gap: 24 }}>
        <Avatar mood="happy" size={140} />

        <div style={{ textAlign: 'center' }}>
          <div style={{ color: '#8B9CC8', fontSize: 14, fontWeight: 500, marginBottom: 8 }}>Tuesday, July 29</div>
          <h1 style={{ color: '#F0F4FF', fontSize: 28, fontWeight: 800, margin: '0 0 8px', lineHeight: 1.2, letterSpacing: '-0.02em' }}>
            Hi Alex 👋<br />
            <span style={{ background: 'linear-gradient(135deg, #2196F3, #39FF14)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              I'm your AI Fitness Coach
            </span>
          </h1>
          <p style={{ color: '#8B9CC8', fontSize: 15, margin: 0, lineHeight: 1.5 }}>
            Let's complete today's workout safely together.
          </p>
        </div>

        {/* Stats row */}
        <div style={{ display: 'flex', gap: 10, width: '100%' }}>
          {stats.map(({ value, unit, label }) => (
            <div key={label} className="glass" style={{ flex: 1, borderRadius: 18, padding: '16px 12px', textAlign: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: 3 }}>
                <span style={{ color: '#F0F4FF', fontSize: 26, fontWeight: 800, fontFamily: "'Space Mono', monospace" }}>{value}</span>
                <span style={{ color: '#39FF14', fontSize: 13, fontWeight: 700 }}>{unit}</span>
              </div>
              <div style={{ color: '#8B9CC8', fontSize: 12, marginTop: 4 }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Info card */}
      <div style={{ margin: '24px 24px 0' }}>
        <div className="glass-blue" style={{ borderRadius: 20, padding: 20 }}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <div style={{ width: 40, height: 40, borderRadius: 12, background: 'rgba(33,150,243,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>🎯</div>
            <div>
              <div style={{ color: '#F0F4FF', fontWeight: 700, fontSize: 15, marginBottom: 4 }}>Full Body Warm-Up Session</div>
              <div style={{ color: '#93C5FD', fontSize: 13, lineHeight: 1.5 }}>
                A gentle 20-min session designed specifically for beginners. I'll guide you through every move safely.
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 8, marginTop: 16, flexWrap: 'wrap' }}>
            {['🔥 Low Impact', '🛡️ Beginner Safe', '⏱️ 20 min'].map(tag => (
              <span key={tag} style={{ background: 'rgba(33,150,243,0.15)', color: '#93C5FD', fontSize: 12, fontWeight: 600, padding: '4px 12px', borderRadius: 100, border: '1px solid rgba(33,150,243,0.2)' }}>
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* AI message */}
      <div style={{ margin: '16px 24px 0' }}>
        <div style={{ background: 'rgba(57,255,20,0.06)', borderRadius: 16, padding: '14px 18px', border: '1px solid rgba(57,255,20,0.15)', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <span style={{ fontSize: 18, flexShrink: 0 }}>🤖</span>
          <p style={{ color: '#A8F5A0', fontSize: 13, margin: 0, lineHeight: 1.5, fontStyle: 'italic' }}>
            "You're doing great just by showing up! There's no wrong pace — let's move at your comfort level."
          </p>
        </div>
      </div>

      {/* CTA buttons */}
      <div style={{ padding: '24px 24px 0', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <button className="btn-accent" onClick={onStart}>
          Start Session ✨
        </button>
        <button className="btn-ghost" onClick={onDashboard}>
          View Dashboard
        </button>
      </div>
    </div>
  )
}
