import CircularProgress from '../components/CircularProgress'
import Avatar from '../components/Avatar'

export default function DesignSystemPage({ onBack }: { onBack: () => void }) {
  return (
    <div style={{ minHeight: 844, background: '#080910', overflowY: 'auto', padding: '0 0 48px' }}>
      {/* Header */}
      <div style={{ padding: '20px 24px 24px', background: 'rgba(33,150,243,0.05)', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        <button onClick={onBack} style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)', color: '#8B9CC8', cursor: 'pointer', marginBottom: 12, fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>←</button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
          <span style={{ color: '#39FF14', fontSize: 11, fontWeight: 700, background: 'rgba(57,255,20,0.1)', padding: '2px 8px', borderRadius: 100, border: '1px solid rgba(57,255,20,0.2)' }}>DESIGN SYSTEM</span>
        </div>
        <h1 style={{ color: '#F0F4FF', fontSize: 22, fontWeight: 800, margin: 0 }}>FitAI Coach</h1>
        <p style={{ color: '#8B9CC8', fontSize: 13, margin: '4px 0 0' }}>Component Library & Design Tokens</p>
      </div>

      <div style={{ padding: '24px' }}>
        {/* Color palette */}
        <Section title="Color System">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {[
              { name: 'Electric Blue', hex: '#2196F3', use: 'Primary actions' },
              { name: 'Neon Green', hex: '#39FF14', use: 'Success/CTA' },
              { name: 'Deep Navy', hex: '#080910', use: 'Background' },
              { name: 'Muted Blue', hex: '#8B9CC8', use: 'Secondary text' },
              { name: 'Violet', hex: '#8B5CF6', use: 'Rest/Recovery' },
              { name: 'Amber', hex: '#F59E0B', use: 'Warnings' },
              { name: 'Red', hex: '#EF4444', use: 'Danger/Pain' },
              { name: 'Glass', hex: 'rgba(255,255,255,0.05)', use: 'Card surfaces' },
            ].map(({ name, hex, use }) => (
              <div key={name} style={{ display: 'flex', gap: 10, alignItems: 'center', padding: '10px', background: 'rgba(255,255,255,0.03)', borderRadius: 12, border: '1px solid rgba(255,255,255,0.06)' }}>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: hex, flexShrink: 0, border: '1px solid rgba(255,255,255,0.1)' }} />
                <div>
                  <div style={{ color: '#F0F4FF', fontSize: 12, fontWeight: 600 }}>{name}</div>
                  <div style={{ color: '#8B9CC8', fontSize: 10, fontFamily: "'Space Mono', monospace" }}>{use}</div>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* Typography */}
        <Section title="Typography">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {[
              { size: 32, weight: 800, label: 'Display / Heading', sample: 'FitAI Coach', font: "'Plus Jakarta Sans'" },
              { size: 22, weight: 700, label: 'Title', sample: 'Today\'s Workout', font: "'Plus Jakarta Sans'" },
              { size: 16, weight: 600, label: 'Subtitle', sample: 'Exercise instructions', font: "'Plus Jakarta Sans'" },
              { size: 14, weight: 400, label: 'Body', sample: 'Keep your core engaged...', font: "'Plus Jakarta Sans'" },
              { size: 28, weight: 800, label: 'Timer / Data', sample: '02:45', font: "'Space Mono'" },
              { size: 12, weight: 700, label: 'Label / Badge', sample: 'LIVE WORKOUT', font: "'Plus Jakarta Sans'" },
            ].map(({ size, weight, label, sample, font }) => (
              <div key={label} style={{ padding: '12px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                <div style={{ color: '#3A4A6B', fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', marginBottom: 4 }}>{label} · {size}px / {weight}</div>
                <div style={{ color: '#F0F4FF', fontSize: size, fontWeight: weight, fontFamily: font, lineHeight: 1.2 }}>{sample}</div>
              </div>
            ))}
          </div>
        </Section>

        {/* Buttons */}
        <Section title="Button Components">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <button className="btn-accent">Primary CTA — Start Workout ✨</button>
            <button className="btn-primary">Secondary — Continue →</button>
            <button className="btn-ghost">Ghost — Skip for Now</button>
            <button className="btn-danger">Danger — Stop Session</button>
            <div style={{ display: 'flex', gap: 10 }}>
              <button style={{ flex: 1, padding: '12px', borderRadius: 14, background: 'rgba(33,150,243,0.12)', border: '1px solid rgba(33,150,243,0.25)', color: '#93C5FD', fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>Too Hard 😓</button>
              <button style={{ flex: 1, padding: '12px', borderRadius: 14, background: 'rgba(57,255,20,0.08)', border: '1px solid rgba(57,255,20,0.2)', color: '#A8F5A0', fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>Too Easy 💪</button>
            </div>
          </div>
        </Section>

        {/* Cards */}
        <Section title="Card Variants">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div className="glass" style={{ borderRadius: 16, padding: '16px', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div style={{ color: '#F0F4FF', fontWeight: 600, fontSize: 14 }}>Standard Glass Card</div>
              <div style={{ color: '#8B9CC8', fontSize: 12, marginTop: 4 }}>Used for exercise info, stats, history items</div>
            </div>
            <div className="glass-blue" style={{ borderRadius: 16, padding: '16px' }}>
              <div style={{ color: '#93C5FD', fontWeight: 600, fontSize: 14 }}>Blue Glass — AI Tips</div>
              <div style={{ color: '#8B9CC8', fontSize: 12, marginTop: 4 }}>Form cues, recommendations, info cards</div>
            </div>
            <div className="glass-green" style={{ borderRadius: 16, padding: '16px' }}>
              <div style={{ color: '#A8F5A0', fontWeight: 600, fontSize: 14 }}>Green Glass — Success States</div>
              <div style={{ color: '#8B9CC8', fontSize: 12, marginTop: 4 }}>Completed workouts, achievements</div>
            </div>
            <div className="glass-red" style={{ borderRadius: 16, padding: '16px' }}>
              <div style={{ color: '#FCA5A5', fontWeight: 600, fontSize: 14 }}>Red Glass — Warnings</div>
              <div style={{ color: '#FCA5A5', fontSize: 12, marginTop: 4, opacity: 0.8 }}>Pain alerts, safety notices, high intensity</div>
            </div>
          </div>
        </Section>

        {/* Progress components */}
        <Section title="Progress Components">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <div style={{ display: 'flex', gap: 20, justifyContent: 'center', flexWrap: 'wrap' }}>
              {[
                { value: 75, color: '#2196F3', label: 'Workout' },
                { value: 50, color: '#39FF14', label: 'Timer' },
                { value: 90, color: '#8B5CF6', label: 'Rest' },
              ].map(({ value, color, label }) => (
                <div key={label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                  <CircularProgress value={value} max={100} size={70} strokeWidth={7} color={color}>
                    <span style={{ color: '#F0F4FF', fontSize: 16, fontWeight: 800, fontFamily: "'Space Mono', monospace" }}>{value}</span>
                  </CircularProgress>
                  <span style={{ color: '#8B9CC8', fontSize: 12 }}>{label}</span>
                </div>
              ))}
            </div>
            {[
              { label: 'Workout Progress', value: 65, color: 'linear-gradient(90deg, #2196F3, #39FF14)' },
              { label: 'Weekly Goal', value: 80, color: 'linear-gradient(90deg, #8B5CF6, #2196F3)' },
              { label: 'Calories', value: 45, color: 'linear-gradient(90deg, #F59E0B, #EF4444)' },
            ].map(({ label, value, color }) => (
              <div key={label}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <span style={{ color: '#8B9CC8', fontSize: 12 }}>{label}</span>
                  <span style={{ color: '#F0F4FF', fontSize: 12, fontWeight: 700 }}>{value}%</span>
                </div>
                <div style={{ height: 6, background: 'rgba(255,255,255,0.06)', borderRadius: 3 }}>
                  <div style={{ width: `${value}%`, height: '100%', background: color, borderRadius: 3 }} />
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* Avatar states */}
        <Section title="AI Avatar States">
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', justifyContent: 'center' }}>
            {(['happy', 'encouraging', 'resting', 'concerned', 'celebrating'] as const).map(mood => (
              <div key={mood} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                <Avatar mood={mood} size={64} animate={false} />
                <span style={{ color: '#8B9CC8', fontSize: 11, textTransform: 'capitalize' }}>{mood}</span>
              </div>
            ))}
          </div>
        </Section>

        {/* Status chips */}
        <Section title="Status Chips & Badges">
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
            {[
              { label: 'LIVE', bg: 'rgba(239,68,68,0.2)', color: '#FCA5A5', border: 'rgba(239,68,68,0.4)' },
              { label: 'BEGINNER SAFE', bg: 'rgba(57,255,20,0.1)', color: '#A8F5A0', border: 'rgba(57,255,20,0.3)' },
              { label: 'AI POWERED', bg: 'rgba(33,150,243,0.15)', color: '#93C5FD', border: 'rgba(33,150,243,0.3)' },
              { label: 'PROTOTYPE', bg: 'rgba(139,92,246,0.15)', color: '#C4B5FD', border: 'rgba(139,92,246,0.3)' },
              { label: '20 MIN', bg: 'rgba(245,158,11,0.12)', color: '#FCD34D', border: 'rgba(245,158,11,0.3)' },
              { label: '✅ COMPLETED', bg: 'rgba(57,255,20,0.08)', color: '#39FF14', border: 'rgba(57,255,20,0.2)' },
            ].map(({ label, bg, color, border }) => (
              <span key={label} style={{ background: bg, color, border: `1px solid ${border}`, borderRadius: 100, padding: '5px 14px', fontSize: 11, fontWeight: 700, letterSpacing: '0.06em' }}>
                {label}
              </span>
            ))}
          </div>
        </Section>

        {/* Spacing */}
        <Section title="Spacing Scale">
          <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
            {[4, 8, 12, 16, 20, 24, 32, 48].map(s => (
              <div key={s} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                <div style={{ width: s/2 + 8, height: s, background: 'rgba(33,150,243,0.3)', borderRadius: 3, border: '1px solid rgba(33,150,243,0.4)' }} />
                <span style={{ color: '#3A4A6B', fontSize: 10 }}>{s}</span>
              </div>
            ))}
          </div>
        </Section>

        {/* Design rationale */}
        <Section title="Design Rationale">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {[
              {
                title: '🎨 Premium Dark Aesthetic',
                body: 'The deep navy background (#080910) creates premium contrast similar to Apple Fitness and Whoop. Dark themes reduce eye strain during workouts when users focus on screens in varying light conditions.',
              },
              {
                title: '⚡ Electric Blue + Neon Green',
                body: 'Electric blue (#2196F3) signals trust and clarity — critical for a health app. Neon green (#39FF14) is reserved exclusively for success states, CTAs, and achievement — creating instant visual hierarchy without text.',
              },
              {
                title: '🛡️ Safety-First Language',
                body: 'All copy avoids shame, judgment, or unrealistic expectations. Pain and difficulty reports trigger supportive, non-judgmental flows. The AI voice is warm, encouraging, and never pushy.',
              },
              {
                title: '💎 Glassmorphism Cards',
                body: 'Glass-effect cards (backdrop-filter: blur) create depth while maintaining readability. Four semantic glass variants — neutral, blue, green, red — communicate context without reading text.',
              },
              {
                title: '🔤 Plus Jakarta Sans + Space Mono',
                body: 'Plus Jakarta Sans (weights 300–800) provides energetic, modern hierarchy. Space Mono handles all numerical data — timers, reps, calories — providing instant visual separation between labels and live data.',
              },
              {
                title: '♿ Accessibility',
                body: 'Large touch targets (40px+ minimum), high contrast text, color + icon redundancy for status chips, readable 13px+ body copy, no shame-based language, and anxiety-aware onboarding tone.',
              },
            ].map(({ title, body }) => (
              <div key={title} style={{ padding: '16px', background: 'rgba(255,255,255,0.03)', borderRadius: 14, border: '1px solid rgba(255,255,255,0.06)' }}>
                <div style={{ color: '#F0F4FF', fontWeight: 700, fontSize: 14, marginBottom: 8 }}>{title}</div>
                <p style={{ color: '#8B9CC8', fontSize: 13, margin: 0, lineHeight: 1.6 }}>{body}</p>
              </div>
            ))}
          </div>
        </Section>
      </div>
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 32 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
        <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.06)' }} />
        <h2 style={{ color: '#F0F4FF', fontSize: 13, fontWeight: 700, margin: 0, letterSpacing: '0.06em', whiteSpace: 'nowrap' }}>{title}</h2>
        <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.06)' }} />
      </div>
      {children}
    </div>
  )
}
