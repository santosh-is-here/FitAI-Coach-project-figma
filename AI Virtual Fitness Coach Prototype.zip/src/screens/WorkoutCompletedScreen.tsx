import { useState, useEffect } from 'react'
import Avatar from '../components/Avatar'

function Confetti() {
  const pieces = Array.from({ length: 24 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    color: ['#2196F3', '#39FF14', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'][i % 6],
    size: Math.random() * 8 + 6,
    delay: Math.random() * 2,
    duration: Math.random() * 2 + 2,
  }))

  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden' }}>
      {pieces.map(p => (
        <div key={p.id} style={{
          position: 'absolute',
          left: `${p.x}%`,
          top: -20,
          width: p.size,
          height: p.size,
          background: p.color,
          borderRadius: Math.random() > 0.5 ? '50%' : 2,
          animation: `confetti-fall ${p.duration}s ${p.delay}s ease-in forwards`,
          opacity: 0.9,
        }} />
      ))}
    </div>
  )
}

export default function WorkoutCompletedScreen({ onDone }: { onDone: () => void }) {
  const [showStats, setShowStats] = useState(false)
  const [effort, setEffort] = useState(0)
  const [mood, setMood] = useState('')

  useEffect(() => {
    const t = setTimeout(() => setShowStats(true), 600)
    return () => clearTimeout(t)
  }, [])

  const stats = [
    { label: 'Duration', value: '21', unit: 'min', icon: '⏱️', color: '#2196F3' },
    { label: 'Calories', value: '162', unit: 'cal', icon: '🔥', color: '#F59E0B' },
    { label: 'Exercises', value: '6', unit: '/6', icon: '✅', color: '#39FF14' },
    { label: 'Avg Pace', value: 'Moderate', unit: '', icon: '📊', color: '#8B5CF6' },
  ]

  return (
    <div style={{ minHeight: 844, background: '#080910', position: 'relative', overflowY: 'auto', overflowX: 'hidden' }}>
      <Confetti />

      {/* Hero celebration */}
      <div style={{
        background: 'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(57,255,20,0.25) 0%, transparent 70%)',
        padding: '48px 24px 32px',
        display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center',
      }}>
        <Avatar mood="celebrating" size={130} />

        <div style={{ margin: '20px 0 0' }}>
          <div style={{ fontSize: 48, marginBottom: 8 }}>🎉</div>
          <h1 style={{ color: '#F0F4FF', fontSize: 30, fontWeight: 800, margin: '0 0 8px', lineHeight: 1.1 }}>
            Workout{' '}
            <span style={{ background: 'linear-gradient(135deg, #39FF14, #2196F3)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              Complete!
            </span>
          </h1>
          <p style={{ color: '#8B9CC8', fontSize: 15, margin: 0, lineHeight: 1.5 }}>
            You showed up and gave it your all. That's what matters most. 🙌
          </p>
        </div>

        {/* Achievement badge */}
        <div style={{ marginTop: 20, background: 'rgba(57,255,20,0.1)', borderRadius: 100, padding: '8px 20px', border: '1px solid rgba(57,255,20,0.3)', display: 'flex', gap: 8, alignItems: 'center' }}>
          <span>⭐</span>
          <span style={{ color: '#39FF14', fontWeight: 700, fontSize: 14 }}>First Workout Completed!</span>
        </div>
      </div>

      {/* Stats grid */}
      <div style={{ padding: '0 24px', opacity: showStats ? 1 : 0, transition: 'opacity 0.6s ease' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 24 }}>
          {stats.map(({ label, value, unit, icon, color }) => (
            <div key={label} className="glass" style={{ borderRadius: 20, padding: '20px 16px', textAlign: 'center' }}>
              <div style={{ fontSize: 24, marginBottom: 8 }}>{icon}</div>
              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'baseline', gap: 3 }}>
                <span style={{ color, fontSize: 28, fontWeight: 800, fontFamily: "'Space Mono', monospace" }}>{value}</span>
                <span style={{ color: '#8B9CC8', fontSize: 13 }}>{unit}</span>
              </div>
              <div style={{ color: '#8B9CC8', fontSize: 13, marginTop: 4 }}>{label}</div>
            </div>
          ))}
        </div>

        {/* Effort rating */}
        <div className="glass" style={{ borderRadius: 20, padding: '20px', marginBottom: 16 }}>
          <h3 style={{ color: '#F0F4FF', fontSize: 15, fontWeight: 700, margin: '0 0 14px' }}>
            How hard did it feel?
          </h3>
          <div style={{ display: 'flex', gap: 8 }}>
            {[1, 2, 3, 4, 5].map(n => (
              <button key={n} onClick={() => setEffort(n)} style={{
                flex: 1, aspectRatio: '1', borderRadius: 12,
                background: effort >= n ? 'rgba(33,150,243,0.25)' : 'rgba(255,255,255,0.05)',
                border: effort >= n ? '1px solid rgba(33,150,243,0.4)' : '1px solid rgba(255,255,255,0.08)',
                cursor: 'pointer', fontSize: 20, display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {['😌', '🙂', '😤', '💪', '🔥'][n - 1]}
              </button>
            ))}
          </div>
          {effort > 0 && (
            <p style={{ color: '#93C5FD', fontSize: 13, textAlign: 'center', margin: '12px 0 0', fontStyle: 'italic' }}>
              {['Nice and easy!', 'Comfortable pace!', 'Solid effort!', 'Working hard!', 'Maximum effort!'][effort - 1]}
            </p>
          )}
        </div>

        {/* Mood */}
        <div className="glass" style={{ borderRadius: 20, padding: '20px', marginBottom: 20 }}>
          <h3 style={{ color: '#F0F4FF', fontSize: 15, fontWeight: 700, margin: '0 0 14px' }}>
            How do you feel now?
          </h3>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {[
              { id: 'Amazing!', emoji: '🤩' },
              { id: 'Good!', emoji: '😊' },
              { id: 'Tired', emoji: '😴' },
              { id: 'Proud', emoji: '💪' },
            ].map(({ id, emoji }) => (
              <button key={id} onClick={() => setMood(id)} style={{
                flex: '1 1 40%', padding: '12px', borderRadius: 14,
                border: mood === id ? '2px solid #39FF14' : '1px solid rgba(255,255,255,0.08)',
                background: mood === id ? 'rgba(57,255,20,0.1)' : 'rgba(255,255,255,0.04)',
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8, justifyContent: 'center',
              }}>
                <span style={{ fontSize: 20 }}>{emoji}</span>
                <span style={{ color: mood === id ? '#A8F5A0' : '#8B9CC8', fontWeight: 600, fontSize: 14 }}>{id}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Recovery tip */}
        <div className="glass-green" style={{ borderRadius: 18, padding: '18px', marginBottom: 24 }}>
          <div style={{ color: '#A8F5A0', fontWeight: 700, fontSize: 14, marginBottom: 6 }}>💚 Today's Recovery Tip</div>
          <p style={{ color: '#8B9CC8', fontSize: 13, margin: 0, lineHeight: 1.5 }}>
            Rest tomorrow or do gentle walking. Your muscles grow and strengthen during recovery, not during the workout itself.
          </p>
        </div>

        {/* AI message */}
        <div style={{ background: 'rgba(33,150,243,0.08)', borderRadius: 16, padding: '16px 18px', marginBottom: 24, border: '1px solid rgba(33,150,243,0.15)' }}>
          <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <span style={{ fontSize: 20 }}>🤖</span>
            <p style={{ color: '#93C5FD', fontSize: 13, margin: 0, lineHeight: 1.5, fontStyle: 'italic' }}>
              "I'm so proud of you! You completed your very first session with me. Every expert was once a beginner — and you've just taken the hardest step."
            </p>
          </div>
        </div>
      </div>

      {/* CTA buttons */}
      <div style={{ padding: '0 24px 48px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <button className="btn-accent" onClick={onDone}>
          🏠 View Dashboard
        </button>
        <button className="btn-primary" onClick={onDone}>
          📅 Schedule Next Workout
        </button>
        <button className="btn-ghost" onClick={onDone}>
          View Progress
        </button>
      </div>
    </div>
  )
}
