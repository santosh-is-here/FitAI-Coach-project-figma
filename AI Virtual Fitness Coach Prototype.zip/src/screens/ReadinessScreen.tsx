import Avatar from '../components/Avatar'

const exercises = [
  { name: 'Marching in Place', muscle: 'Cardio', duration: '2 min', icon: '🚶' },
  { name: 'Arm Circles', muscle: 'Shoulders', duration: '1 min', icon: '🔄' },
  { name: 'Squats', muscle: 'Legs', duration: '2 min', icon: '🦵' },
  { name: 'Wall Push-ups', muscle: 'Chest', duration: '2 min', icon: '🤲' },
  { name: 'Glute Bridge', muscle: 'Glutes', duration: '2 min', icon: '🍑' },
  { name: 'Knee Raises', muscle: 'Core', duration: '2 min', icon: '🦵' },
  { name: 'Plank', muscle: 'Core', duration: '1 min', icon: '💪' },
  { name: 'Side Bends', muscle: 'Obliques', duration: '1 min', icon: '↔️' },
  { name: 'Cat-Cow Stretch', muscle: 'Spine', duration: '2 min', icon: '🐱' },
  { name: 'Forward Fold', muscle: 'Hamstrings', duration: '1 min', icon: '🧘' },
]

const phases = [
  { name: 'Warm-up', duration: '5 min', color: '#F59E0B', exercises: 2 },
  { name: 'Main Workout', duration: '12 min', color: '#2196F3', exercises: 6 },
  { name: 'Cool-down', duration: '3 min', color: '#39FF14', exercises: 2 },
]

export default function ReadinessScreen({ onStart, onBack }: { onStart: () => void; onBack: () => void }) {
  return (
    <div style={{ minHeight: 844, background: '#080910', overflowY: 'auto' }}>
      {/* Header */}
      <div style={{
        background: 'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(33,150,243,0.2) 0%, transparent 70%)',
        padding: '20px 24px 32px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
          <button onClick={onBack} style={{ width: 40, height: 40, borderRadius: 12, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)', color: '#8B9CC8', cursor: 'pointer', fontSize: 18 }}>←</button>
          <span style={{ color: '#8B9CC8', fontSize: 14, fontWeight: 600 }}>Your Personalized Workout</span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
          <Avatar mood="happy" size={90} />
          <div>
            <div style={{ color: '#8B9CC8', fontSize: 13, marginBottom: 4 }}>Today's Plan</div>
            <div style={{ color: '#F0F4FF', fontSize: 26, fontWeight: 800, lineHeight: 1.1 }}>
              Full Body<br />
              <span style={{ background: 'linear-gradient(135deg, #2196F3, #39FF14)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                Beginner Session
              </span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
          {[
            { value: '20', unit: 'min', label: 'Duration' },
            { value: '10', unit: 'ex', label: 'Exercises' },
            { value: '~150', unit: 'cal', label: 'Est. Calories' },
          ].map(({ value, unit, label }) => (
            <div key={label} className="glass" style={{ flex: 1, borderRadius: 16, padding: '14px 10px', textAlign: 'center' }}>
              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'baseline', gap: 2 }}>
                <span style={{ color: '#F0F4FF', fontSize: 22, fontWeight: 800, fontFamily: "'Space Mono', monospace" }}>{value}</span>
                <span style={{ color: '#39FF14', fontSize: 11, fontWeight: 700 }}>{unit}</span>
              </div>
              <div style={{ color: '#8B9CC8', fontSize: 11, marginTop: 3 }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Phases */}
      <div style={{ padding: '0 24px' }}>
        <div style={{ display: 'flex', gap: 0, marginBottom: 24, background: 'rgba(255,255,255,0.04)', borderRadius: 14, overflow: 'hidden', border: '1px solid rgba(255,255,255,0.06)' }}>
          {phases.map((phase, i) => (
            <div key={phase.name} style={{
              flex: 1, padding: '14px 10px', textAlign: 'center',
              borderRight: i < phases.length - 1 ? '1px solid rgba(255,255,255,0.06)' : 'none',
            }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: phase.color, margin: '0 auto 6px' }} />
              <div style={{ color: '#F0F4FF', fontWeight: 700, fontSize: 12 }}>{phase.name}</div>
              <div style={{ color: phase.color, fontWeight: 700, fontSize: 14, fontFamily: "'Space Mono', monospace" }}>{phase.duration}</div>
              <div style={{ color: '#8B9CC8', fontSize: 11 }}>{phase.exercises} exercises</div>
            </div>
          ))}
        </div>

        {/* Exercise list */}
        <h3 style={{ color: '#F0F4FF', fontSize: 16, fontWeight: 700, margin: '0 0 14px' }}>Exercise Preview</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {exercises.map((ex, i) => (
            <div key={ex.name} className="glass" style={{ borderRadius: 14, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(33,150,243,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>
                {ex.icon}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ color: '#F0F4FF', fontWeight: 600, fontSize: 14 }}>{ex.name}</div>
                <div style={{ color: '#8B9CC8', fontSize: 12 }}>{ex.muscle}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ color: '#39FF14', fontSize: 13, fontWeight: 700, fontFamily: "'Space Mono', monospace" }}>{ex.duration}</div>
                <div style={{ color: '#3A4A6B', fontSize: 11 }}>#{i + 1}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Safety reminder */}
        <div className="glass-red" style={{ borderRadius: 18, padding: '18px 20px', margin: '20px 0 8px' }}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <span style={{ fontSize: 24, flexShrink: 0 }}>🛡️</span>
            <div>
              <div style={{ color: '#FCA5A5', fontWeight: 700, fontSize: 15, marginBottom: 6 }}>Safety First</div>
              <p style={{ color: '#FCA5A5', fontSize: 13, margin: 0, lineHeight: 1.5, opacity: 0.9 }}>
                Stop immediately if you feel sharp pain, dizziness, or shortness of breath. It's always okay to take a break or modify any exercise.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div style={{ padding: '16px 24px 40px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <button className="btn-accent animate-glow" onClick={onStart}>
          🚀 Let's Go!
        </button>
        <button className="btn-ghost" onClick={onBack}>
          Edit Setup
        </button>
      </div>
    </div>
  )
}
