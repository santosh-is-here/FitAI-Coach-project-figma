import { useState } from 'react'
import Avatar from '../components/Avatar'

interface AssessmentData {
  age: string
  gender: string
  fitnessLevel: string
  goal: string
  energy: number
  duration: string
  equipment: string[]
  hasInjury: string
  painToday: string
  frequency: string
  mood: string
}

const steps = [
  { id: 'age', q: "How old are you?", sub: "This helps me personalize your workout safely." },
  { id: 'gender', q: "How do you identify?", sub: "Used only to customize exercise recommendations." },
  { id: 'fitnessLevel', q: "What's your current fitness level?", sub: "Be honest — there's no wrong answer!" },
  { id: 'goal', q: "What's your primary goal?", sub: "I'll tailor the session to what matters most to you." },
  { id: 'energy', q: "How's your energy right now?", sub: "On a scale from 1 (exhausted) to 10 (pumped up)." },
  { id: 'duration', q: "How long would you like to workout?", sub: "Pick whatever feels right for today." },
  { id: 'equipment', q: "What equipment do you have?", sub: "Select all that apply. None is perfectly fine!" },
  { id: 'injury', q: "Any existing injuries or pain today?", sub: "Your safety is my top priority." },
  { id: 'frequency', q: "How often do you currently work out?", sub: "Honesty helps me set realistic expectations." },
  { id: 'mood', q: "How are you feeling emotionally?", sub: "Your mindset matters as much as your fitness." },
]

export default function AssessmentScreen({ onComplete, onBack }: { onComplete: () => void; onBack: () => void }) {
  const [step, setStep] = useState(0)
  const [data, setData] = useState<Partial<AssessmentData>>({ energy: 6, equipment: [] })

  const progress = ((step + 1) / steps.length) * 100
  const current = steps[step]

  const set = (key: keyof AssessmentData, val: any) => setData(d => ({ ...d, [key]: val }))

  const toggleEquipment = (item: string) => {
    const cur = data.equipment || []
    set('equipment', cur.includes(item) ? cur.filter(e => e !== item) : [...cur, item])
  }

  const next = () => {
    if (step < steps.length - 1) setStep(s => s + 1)
    else onComplete()
  }

  const back = () => {
    if (step > 0) setStep(s => s - 1)
    else onBack()
  }

  const canProceed = () => {
    if (current.id === 'age') return !!data.age
    if (current.id === 'gender') return !!data.gender
    if (current.id === 'fitnessLevel') return !!data.fitnessLevel
    if (current.id === 'goal') return !!data.goal
    if (current.id === 'duration') return !!data.duration
    if (current.id === 'injury') return !!data.hasInjury
    if (current.id === 'frequency') return !!data.frequency
    if (current.id === 'mood') return !!data.mood
    return true
  }

  const renderInput = () => {
    switch (current.id) {
      case 'age':
        return (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
            {['18–24','25–34','35–44','45–54','55–64','65+'].map(a => (
              <button key={a} onClick={() => set('age', a)} style={{
                padding: '14px 8px', borderRadius: 14, border: data.age === a ? '2px solid #2196F3' : '1px solid rgba(255,255,255,0.08)',
                background: data.age === a ? 'rgba(33,150,243,0.2)' : 'rgba(255,255,255,0.04)',
                color: data.age === a ? '#93C5FD' : '#8B9CC8', fontWeight: 600, fontSize: 14, cursor: 'pointer',
              }}>{a}</button>
            ))}
          </div>
        )
      case 'gender':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {['Male','Female','Non-binary','Prefer not to say'].map(g => (
              <button key={g} onClick={() => set('gender', g)} style={{
                padding: '16px 20px', borderRadius: 16, border: data.gender === g ? '2px solid #2196F3' : '1px solid rgba(255,255,255,0.08)',
                background: data.gender === g ? 'rgba(33,150,243,0.15)' : 'rgba(255,255,255,0.04)',
                color: data.gender === g ? '#F0F4FF' : '#8B9CC8', fontWeight: 600, fontSize: 15, cursor: 'pointer', textAlign: 'left',
                display: 'flex', alignItems: 'center', gap: 12,
              }}>
                <div style={{ width: 20, height: 20, borderRadius: '50%', border: `2px solid ${data.gender === g ? '#2196F3' : 'rgba(255,255,255,0.2)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {data.gender === g && <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#2196F3' }} />}
                </div>
                {g}
              </button>
            ))}
          </div>
        )
      case 'fitnessLevel':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              { id: 'Beginner', icon: '🌱', desc: 'Just starting out' },
              { id: 'Intermediate', icon: '💪', desc: 'Some experience' },
              { id: 'Advanced', icon: '🔥', desc: 'Regular training' },
            ].map(({ id, icon, desc }) => (
              <button key={id} onClick={() => set('fitnessLevel', id)} style={{
                padding: '16px 20px', borderRadius: 16, border: data.fitnessLevel === id ? '2px solid #39FF14' : '1px solid rgba(255,255,255,0.08)',
                background: data.fitnessLevel === id ? 'rgba(57,255,20,0.1)' : 'rgba(255,255,255,0.04)',
                color: '#F0F4FF', cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 14,
              }}>
                <span style={{ fontSize: 28 }}>{icon}</span>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 16 }}>{id}</div>
                  <div style={{ color: '#8B9CC8', fontSize: 13 }}>{desc}</div>
                </div>
              </button>
            ))}
          </div>
        )
      case 'goal':
        return (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {[
              { id: 'Weight Loss', icon: '⚖️' },
              { id: 'Muscle Gain', icon: '💪' },
              { id: 'General Fitness', icon: '❤️' },
              { id: 'Flexibility', icon: '🧘' },
            ].map(({ id, icon }) => (
              <button key={id} onClick={() => set('goal', id)} style={{
                padding: '20px 14px', borderRadius: 18, border: data.goal === id ? '2px solid #2196F3' : '1px solid rgba(255,255,255,0.08)',
                background: data.goal === id ? 'rgba(33,150,243,0.15)' : 'rgba(255,255,255,0.04)',
                color: data.goal === id ? '#F0F4FF' : '#8B9CC8', cursor: 'pointer', textAlign: 'center',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
              }}>
                <span style={{ fontSize: 32 }}>{icon}</span>
                <span style={{ fontWeight: 600, fontSize: 13 }}>{id}</span>
              </button>
            ))}
          </div>
        )
      case 'energy':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ color: '#8B9CC8', fontSize: 14 }}>Exhausted 😴</span>
              <span style={{ color: '#39FF14', fontWeight: 800, fontSize: 28, fontFamily: "'Space Mono', monospace" }}>
                {data.energy}
              </span>
              <span style={{ color: '#8B9CC8', fontSize: 14 }}>Pumped 💥</span>
            </div>
            <div style={{ position: 'relative', height: 48, display: 'flex', alignItems: 'center' }}>
              <div style={{ width: '100%', height: 6, background: 'rgba(255,255,255,0.08)', borderRadius: 3, position: 'relative' }}>
                <div style={{ width: `${((data.energy || 6) - 1) / 9 * 100}%`, height: '100%', background: 'linear-gradient(90deg, #2196F3, #39FF14)', borderRadius: 3, transition: 'width 0.1s ease' }} />
              </div>
              <input type="range" min={1} max={10} value={data.energy || 6}
                onChange={e => set('energy', Number(e.target.value))}
                style={{ position: 'absolute', inset: 0, opacity: 0, cursor: 'pointer', width: '100%', height: '100%' }}
              />
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
              {Array.from({ length: 10 }, (_, i) => i + 1).map(n => (
                <div key={n} style={{
                  width: 28, height: 28, borderRadius: 8,
                  background: n <= (data.energy || 6) ? 'rgba(33,150,243,0.4)' : 'rgba(255,255,255,0.06)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: n <= (data.energy || 6) ? '#93C5FD' : '#3A4A6B',
                  fontSize: 11, fontWeight: 600,
                }}>{n}</div>
              ))}
            </div>
          </div>
        )
      case 'duration':
        return (
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {['10 min','20 min','30 min','45 min'].map(d => (
              <button key={d} onClick={() => set('duration', d)} style={{
                flex: '1 1 40%', padding: '20px', borderRadius: 18,
                border: data.duration === d ? '2px solid #39FF14' : '1px solid rgba(255,255,255,0.08)',
                background: data.duration === d ? 'rgba(57,255,20,0.12)' : 'rgba(255,255,255,0.04)',
                color: data.duration === d ? '#39FF14' : '#8B9CC8', fontWeight: 700, fontSize: 18,
                cursor: 'pointer', fontFamily: "'Space Mono', monospace",
              }}>{d}</button>
            ))}
          </div>
        )
      case 'equipment':
        return (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {[
              { id: 'None', icon: '🚫' },
              { id: 'Resistance Bands', icon: '〰️' },
              { id: 'Dumbbells', icon: '🏋️' },
              { id: 'Yoga Mat', icon: '🧘' },
              { id: 'Pull-up Bar', icon: '⬆️' },
              { id: 'Home Gym', icon: '🏠' },
            ].map(({ id, icon }) => {
              const sel = (data.equipment || []).includes(id)
              return (
                <button key={id} onClick={() => toggleEquipment(id)} style={{
                  padding: '16px 12px', borderRadius: 16,
                  border: sel ? '2px solid #2196F3' : '1px solid rgba(255,255,255,0.08)',
                  background: sel ? 'rgba(33,150,243,0.15)' : 'rgba(255,255,255,0.04)',
                  color: sel ? '#F0F4FF' : '#8B9CC8', cursor: 'pointer',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                }}>
                  <span style={{ fontSize: 28 }}>{icon}</span>
                  <span style={{ fontWeight: 600, fontSize: 12 }}>{id}</span>
                </button>
              )
            })}
          </div>
        )
      case 'injury':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ display: 'flex', gap: 10 }}>
              {['No injuries','Yes, I have some'].map(opt => (
                <button key={opt} onClick={() => set('hasInjury', opt)} style={{
                  flex: 1, padding: '16px', borderRadius: 16,
                  border: data.hasInjury === opt ? '2px solid #2196F3' : '1px solid rgba(255,255,255,0.08)',
                  background: data.hasInjury === opt ? 'rgba(33,150,243,0.15)' : 'rgba(255,255,255,0.04)',
                  color: data.hasInjury === opt ? '#F0F4FF' : '#8B9CC8',
                  fontWeight: 600, fontSize: 14, cursor: 'pointer',
                }}>{opt}</button>
              ))}
            </div>
            <div style={{ marginTop: 8 }}>
              <p style={{ color: '#8B9CC8', fontSize: 13, margin: '0 0 8px' }}>Any pain today?</p>
              <div style={{ display: 'flex', gap: 8 }}>
                {['None','Mild','Moderate'].map(p => (
                  <button key={p} onClick={() => set('painToday', p)} style={{
                    flex: 1, padding: '12px', borderRadius: 12,
                    border: data.painToday === p ? '2px solid #F59E0B' : '1px solid rgba(255,255,255,0.08)',
                    background: data.painToday === p ? 'rgba(245,158,11,0.12)' : 'rgba(255,255,255,0.04)',
                    color: data.painToday === p ? '#FCD34D' : '#8B9CC8',
                    fontWeight: 600, fontSize: 13, cursor: 'pointer',
                  }}>{p}</button>
                ))}
              </div>
            </div>
            <div className="glass-red" style={{ borderRadius: 14, padding: '12px 16px', marginTop: 8 }}>
              <p style={{ color: '#FCA5A5', fontSize: 12, margin: 0, lineHeight: 1.5 }}>
                🛡️ I'll always modify exercises to work around any discomfort. Your safety comes first.
              </p>
            </div>
          </div>
        )
      case 'frequency':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {['This is my first time','1–2 times/week','3–4 times/week','5+ times/week'].map(f => (
              <button key={f} onClick={() => set('frequency', f)} style={{
                padding: '16px 20px', borderRadius: 16,
                border: data.frequency === f ? '2px solid #2196F3' : '1px solid rgba(255,255,255,0.08)',
                background: data.frequency === f ? 'rgba(33,150,243,0.15)' : 'rgba(255,255,255,0.04)',
                color: data.frequency === f ? '#F0F4FF' : '#8B9CC8',
                fontWeight: 600, fontSize: 15, cursor: 'pointer', textAlign: 'left',
              }}>{f}</button>
            ))}
          </div>
        )
      case 'mood':
        return (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
            {[
              { id: 'Energized', emoji: '⚡' },
              { id: 'Calm', emoji: '😌' },
              { id: 'Motivated', emoji: '🔥' },
              { id: 'Tired', emoji: '😴' },
              { id: 'Anxious', emoji: '😰' },
              { id: 'Happy', emoji: '😊' },
            ].map(({ id, emoji }) => (
              <button key={id} onClick={() => set('mood', id)} style={{
                padding: '18px 10px', borderRadius: 16,
                border: data.mood === id ? '2px solid #39FF14' : '1px solid rgba(255,255,255,0.08)',
                background: data.mood === id ? 'rgba(57,255,20,0.1)' : 'rgba(255,255,255,0.04)',
                cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
              }}>
                <span style={{ fontSize: 30 }}>{emoji}</span>
                <span style={{ color: data.mood === id ? '#A8F5A0' : '#8B9CC8', fontWeight: 600, fontSize: 12 }}>{id}</span>
              </button>
            ))}
          </div>
        )
      default: return null
    }
  }

  return (
    <div style={{ minHeight: 844, background: '#080910', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ padding: '20px 24px 0', display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={back} style={{ width: 40, height: 40, borderRadius: 12, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)', color: '#8B9CC8', cursor: 'pointer', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          ←
        </button>
        <div style={{ flex: 1 }}>
          <div style={{ color: '#8B9CC8', fontSize: 12, marginBottom: 6 }}>
            Question {step + 1} of {steps.length}
          </div>
          <div style={{ height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2 }}>
            <div style={{ width: `${progress}%`, height: '100%', background: 'linear-gradient(90deg, #2196F3, #39FF14)', borderRadius: 2, transition: 'width 0.3s ease' }} />
          </div>
        </div>
      </div>

      {/* Avatar */}
      <div style={{ display: 'flex', justifyContent: 'center', padding: '20px 0 0' }}>
        <Avatar mood="encouraging" size={80} />
      </div>

      {/* Question */}
      <div style={{ padding: '16px 24px 0' }}>
        <h2 style={{ color: '#F0F4FF', fontSize: 22, fontWeight: 800, margin: '0 0 6px', lineHeight: 1.2 }}>
          {current.q}
        </h2>
        <p style={{ color: '#8B9CC8', fontSize: 14, margin: '0 0 24px', lineHeight: 1.5 }}>
          {current.sub}
        </p>
        {renderInput()}
      </div>

      {/* Navigation */}
      <div style={{ padding: '24px 24px 32px', marginTop: 'auto', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <button className="btn-primary" onClick={next} disabled={!canProceed()} style={{
          opacity: canProceed() ? 1 : 0.4,
          cursor: canProceed() ? 'pointer' : 'not-allowed',
        }}>
          {step === steps.length - 1 ? 'Build My Workout →' : 'Continue →'}
        </button>
        {step > 0 && (
          <button onClick={back} style={{ background: 'none', border: 'none', color: '#8B9CC8', cursor: 'pointer', fontSize: 14, fontWeight: 500, padding: 8 }}>
            ← Go back
          </button>
        )}
      </div>
    </div>
  )
}
