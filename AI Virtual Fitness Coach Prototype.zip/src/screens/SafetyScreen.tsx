import Avatar from '../components/Avatar'

export default function SafetyScreen({ onEnd }: { onEnd: () => void }) {
  return (
    <div style={{
      minHeight: 844,
      background: 'radial-gradient(ellipse 70% 50% at 50% 25%, rgba(239,68,68,0.25) 0%, transparent 60%), #080910',
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      padding: '48px 24px 48px',
    }}>
      {/* Emergency header */}
      <div style={{ background: 'rgba(239,68,68,0.2)', borderRadius: 100, padding: '8px 20px', marginBottom: 28, border: '1px solid rgba(239,68,68,0.4)', display: 'flex', gap: 8, alignItems: 'center' }}>
        <span style={{ fontSize: 18 }}>🚨</span>
        <span style={{ color: '#FCA5A5', fontSize: 13, fontWeight: 800, letterSpacing: '0.08em' }}>SAFETY ALERT</span>
      </div>

      <Avatar mood="concerned" size={110} />

      <div style={{ textAlign: 'center', margin: '24px 0 32px' }}>
        <h1 style={{ color: '#F0F4FF', fontSize: 26, fontWeight: 800, margin: '0 0 12px', lineHeight: 1.2 }}>
          Please Stop<br />Exercising
        </h1>
        <p style={{ color: '#8B9CC8', fontSize: 15, margin: 0, lineHeight: 1.6 }}>
          Your safety is the absolute priority. Please consult a healthcare professional before continuing any physical activity.
        </p>
      </div>

      {/* Emergency warning card */}
      <div style={{ width: '100%', background: 'rgba(239,68,68,0.12)', borderRadius: 20, padding: '20px', border: '2px solid rgba(239,68,68,0.3)', marginBottom: 20 }}>
        <div style={{ fontWeight: 800, color: '#EF4444', fontSize: 16, marginBottom: 12 }}>⚠️ Warning Signs Detected</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
            'Stop all physical activity immediately',
            'Sit or lie down in a comfortable position',
            'Drink water if available',
            'If symptoms persist, call emergency services',
          ].map((text, i) => (
            <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
              <div style={{ width: 20, height: 20, borderRadius: '50%', background: 'rgba(239,68,68,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color: '#FCA5A5', fontSize: 11, fontWeight: 700 }}>{i + 1}</div>
              <span style={{ color: '#FCA5A5', fontSize: 14, lineHeight: 1.4 }}>{text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Gentle alternative */}
      <div className="glass" style={{ borderRadius: 18, padding: '18px', width: '100%', marginBottom: 24 }}>
        <div style={{ color: '#F0F4FF', fontWeight: 700, fontSize: 15, marginBottom: 10 }}>🌬️ Gentle Breathing Exercise</div>
        <p style={{ color: '#8B9CC8', fontSize: 13, margin: '0 0 12px', lineHeight: 1.5 }}>
          If you're stable, try this calming breathing technique:
        </p>
        <div style={{ display: 'flex', gap: 8 }}>
          {[
            { step: 'Inhale', time: '4s', color: '#2196F3' },
            { step: 'Hold', time: '4s', color: '#8B5CF6' },
            { step: 'Exhale', time: '6s', color: '#39FF14' },
          ].map(({ step, time, color }) => (
            <div key={step} style={{ flex: 1, background: `${color}15`, borderRadius: 12, padding: '12px 8px', textAlign: 'center', border: `1px solid ${color}30` }}>
              <div style={{ color, fontWeight: 800, fontFamily: "'Space Mono', monospace", fontSize: 16 }}>{time}</div>
              <div style={{ color: '#8B9CC8', fontSize: 12, marginTop: 2 }}>{step}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Emergency contact */}
      <div style={{ width: '100%', marginBottom: 20 }}>
        <a href="tel:911" style={{ display: 'block', textDecoration: 'none' }}>
          <div style={{ background: 'rgba(239,68,68,0.15)', borderRadius: 16, padding: '16px 20px', border: '2px solid rgba(239,68,68,0.4)', display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontSize: 28 }}>📞</span>
            <div>
              <div style={{ color: '#FCA5A5', fontWeight: 800, fontSize: 16 }}>Emergency: Call 911</div>
              <div style={{ color: '#F87171', fontSize: 13 }}>For chest pain, difficulty breathing, or severe symptoms</div>
            </div>
          </div>
        </a>
      </div>

      {/* Medical disclaimer */}
      <div style={{ width: '100%', background: 'rgba(255,255,255,0.03)', borderRadius: 14, padding: '14px 16px', marginBottom: 24, border: '1px solid rgba(255,255,255,0.06)' }}>
        <p style={{ color: '#3A4A6B', fontSize: 11, margin: 0, lineHeight: 1.5, textAlign: 'center' }}>
          FitAI Coach is not a medical device. Always consult a qualified healthcare professional before starting or continuing any exercise program, especially if you experience pain or discomfort.
        </p>
      </div>

      <button className="btn-ghost" onClick={onEnd} style={{ width: '100%', borderColor: 'rgba(239,68,68,0.3)', color: '#FCA5A5' }}>
        End Session Safely
      </button>
    </div>
  )
}
