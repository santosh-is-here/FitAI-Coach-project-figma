import { useState, useEffect } from 'react'
import Avatar from '../components/Avatar'
import CircularProgress from '../components/CircularProgress'

export default function BreakScreen({ onResume, onEnd }: { onResume: () => void; onEnd: () => void }) {
  const [countdown, setCountdown] = useState(60)

  useEffect(() => {
    const t = setInterval(() => setCountdown(c => {
      if (c <= 1) { clearInterval(t); return 0 }
      return c - 1
    }), 1000)
    return () => clearInterval(t)
  }, [])

  return (
    <div style={{
      minHeight: 844,
      background: 'radial-gradient(ellipse 70% 50% at 50% 30%, rgba(139,92,246,0.2) 0%, transparent 60%), #080910',
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      padding: '60px 24px 48px',
    }}>
      <div style={{ background: 'rgba(139,92,246,0.15)', borderRadius: 100, padding: '6px 16px', marginBottom: 24 }}>
        <span style={{ color: '#C4B5FD', fontSize: 13, fontWeight: 700, letterSpacing: '0.08em' }}>REST BREAK</span>
      </div>

      <Avatar mood="resting" size={130} />

      <div style={{ textAlign: 'center', margin: '24px 0 0' }}>
        <h2 style={{ color: '#F0F4FF', fontSize: 26, fontWeight: 800, margin: '0 0 8px' }}>
          Take a breath
        </h2>
        <p style={{ color: '#8B9CC8', fontSize: 15, margin: 0, lineHeight: 1.5 }}>
          You're doing great! A short rest helps your muscles recover.
        </p>
      </div>

      {/* Timer */}
      <div style={{ margin: '32px 0', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
        <CircularProgress value={countdown} max={60} size={140} strokeWidth={10} color="#8B5CF6" trailColor="rgba(139,92,246,0.1)">
          <div style={{ textAlign: 'center' }}>
            <div style={{ color: '#F0F4FF', fontSize: 40, fontWeight: 800, fontFamily: "'Space Mono', monospace", lineHeight: 1 }}>
              {String(countdown).padStart(2, '0')}
            </div>
            <div style={{ color: '#C4B5FD', fontSize: 13 }}>seconds</div>
          </div>
        </CircularProgress>
        {countdown === 0 && (
          <div style={{ color: '#39FF14', fontWeight: 700, fontSize: 14, animation: 'fade-in 0.5s ease' }}>
            Ready when you are! 💪
          </div>
        )}
      </div>

      {/* Hydration reminder */}
      <div className="glass" style={{ borderRadius: 20, padding: '18px 20px', width: '100%', marginBottom: 24 }}>
        <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
          <span style={{ fontSize: 32 }}>💧</span>
          <div>
            <div style={{ color: '#F0F4FF', fontWeight: 700, fontSize: 15, marginBottom: 4 }}>Hydration Reminder</div>
            <p style={{ color: '#8B9CC8', fontSize: 13, margin: 0, lineHeight: 1.5 }}>
              Sip some water! Staying hydrated improves performance and helps prevent cramps.
            </p>
          </div>
        </div>
      </div>

      {/* Breathing tip */}
      <div style={{ width: '100%', background: 'rgba(139,92,246,0.08)', borderRadius: 16, padding: '14px 18px', marginBottom: 24, border: '1px solid rgba(139,92,246,0.2)' }}>
        <div style={{ color: '#C4B5FD', fontWeight: 700, fontSize: 14, marginBottom: 6 }}>🧘 Breathing Tip</div>
        <p style={{ color: '#A78BFA', fontSize: 13, margin: 0, lineHeight: 1.5 }}>
          Inhale for 4 counts, hold for 4, exhale for 6. This activates your parasympathetic system.
        </p>
      </div>

      {/* CTA */}
      <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <button className="btn-accent" onClick={onResume}>
          Resume Workout →
        </button>
        <button className="btn-ghost" onClick={onEnd}>
          End Session for Today
        </button>
      </div>
    </div>
  )
}
