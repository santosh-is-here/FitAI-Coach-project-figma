import { useState, useEffect } from 'react'
import CircularProgress from '../components/CircularProgress'

const stretches = [
  { name: 'Deep Breathing', duration: '2 min', icon: '🌬️', benefit: 'Lowers heart rate' },
  { name: 'Cat-Cow Stretch', duration: '1 min', icon: '🐱', benefit: 'Releases spine tension' },
  { name: 'Forward Fold', duration: '1 min', icon: '🧘', benefit: 'Stretches hamstrings' },
  { name: 'Child\'s Pose', duration: '2 min', icon: '🙇', benefit: 'Full body relaxation' },
  { name: 'Seated Twist', duration: '1 min', icon: '🔄', benefit: 'Detoxifies spine' },
]

export default function CoolDownScreen({ onComplete }: { onComplete: () => void }) {
  const [breathPhase, setBreathPhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale')
  const [breathProgress, setBreathProgress] = useState(0)
  const [breathCount, setBreathCount] = useState(0)

  useEffect(() => {
    const phases: Array<['inhale' | 'hold' | 'exhale', number]> = [['inhale', 4000], ['hold', 4000], ['exhale', 6000]]
    let phaseIdx = 0
    let startTime = Date.now()

    const tick = setInterval(() => {
      const elapsed = Date.now() - startTime
      const [phase, dur] = phases[phaseIdx]
      const pct = Math.min(elapsed / dur, 1)
      setBreathPhase(phase)
      setBreathProgress(pct * 100)

      if (pct >= 1) {
        phaseIdx = (phaseIdx + 1) % phases.length
        startTime = Date.now()
        if (phaseIdx === 0) setBreathCount(c => c + 1)
      }
    }, 50)

    return () => clearInterval(tick)
  }, [])

  const phaseColors = { inhale: '#2196F3', hold: '#8B5CF6', exhale: '#39FF14' }
  const phaseLabels = { inhale: 'Inhale', hold: 'Hold', exhale: 'Exhale' }
  const phaseInstructions = {
    inhale: 'Breathe in slowly through your nose...',
    hold: 'Hold gently...',
    exhale: 'Exhale slowly through your mouth...',
  }

  return (
    <div style={{ minHeight: 844, background: '#080910', overflowY: 'auto' }}>
      {/* Header */}
      <div style={{
        background: 'radial-gradient(ellipse 70% 50% at 50% 0%, rgba(57,255,20,0.15) 0%, transparent 60%)',
        padding: '28px 24px 32px', textAlign: 'center',
      }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'rgba(57,255,20,0.1)', borderRadius: 100, padding: '6px 16px', marginBottom: 16, border: '1px solid rgba(57,255,20,0.2)' }}>
          <span style={{ color: '#39FF14', fontSize: 12, fontWeight: 700 }}>🌿 COOL DOWN</span>
        </div>
        <h1 style={{ color: '#F0F4FF', fontSize: 28, fontWeight: 800, margin: '0 0 8px', lineHeight: 1.2 }}>
          Great work! Time to<br />
          <span style={{ color: '#39FF14' }}>recover</span>
        </h1>
        <p style={{ color: '#8B9CC8', fontSize: 14, margin: 0, lineHeight: 1.5 }}>
          These final minutes are crucial for recovery. Take it slow.
        </p>
      </div>

      {/* Breathing animation */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '0 24px 24px' }}>
        <div style={{ position: 'relative', marginBottom: 16 }}>
          {/* Outer breathing rings */}
          <div style={{
            position: 'absolute',
            inset: -20,
            borderRadius: '50%',
            border: `2px solid ${phaseColors[breathPhase]}`,
            opacity: 0.2,
            transform: breathPhase === 'exhale' ? 'scale(1.2)' : 'scale(1)',
            transition: 'all 0.5s ease',
          }} />

          <CircularProgress
            value={breathProgress}
            max={100}
            size={160}
            strokeWidth={10}
            color={phaseColors[breathPhase]}
            trailColor="rgba(255,255,255,0.04)"
          >
            <div style={{ textAlign: 'center' }}>
              <div style={{
                fontSize: 40,
                transform: breathPhase === 'inhale' ? 'scale(1.1)' : breathPhase === 'exhale' ? 'scale(0.9)' : 'scale(1)',
                transition: 'transform 0.5s ease',
              }}>
                {breathPhase === 'inhale' ? '🌬️' : breathPhase === 'hold' ? '🫁' : '💨'}
              </div>
              <div style={{ color: phaseColors[breathPhase], fontWeight: 800, fontSize: 15, marginTop: 4 }}>
                {phaseLabels[breathPhase]}
              </div>
            </div>
          </CircularProgress>
        </div>

        <p style={{ color: '#8B9CC8', fontSize: 14, textAlign: 'center', margin: '0 0 6px', fontStyle: 'italic' }}>
          {phaseInstructions[breathPhase]}
        </p>
        <div style={{ color: '#39FF14', fontSize: 13, fontWeight: 700, fontFamily: "'Space Mono', monospace" }}>
          Breath {breathCount + 1}
        </div>
      </div>

      {/* Stretch cards */}
      <div style={{ padding: '0 24px' }}>
        <h3 style={{ color: '#F0F4FF', fontSize: 16, fontWeight: 700, margin: '0 0 14px' }}>Recovery Stretches</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {stretches.map((stretch, i) => (
            <div key={stretch.name} className="glass" style={{ borderRadius: 16, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14, opacity: i === 0 ? 1 : 0.7 }}>
              <div style={{
                width: 44, height: 44, borderRadius: 14, flexShrink: 0,
                background: i === 0 ? 'rgba(57,255,20,0.15)' : 'rgba(255,255,255,0.05)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22,
                border: i === 0 ? '1px solid rgba(57,255,20,0.3)' : '1px solid rgba(255,255,255,0.08)',
              }}>
                {stretch.icon}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ color: '#F0F4FF', fontWeight: 600, fontSize: 14 }}>{stretch.name}</div>
                <div style={{ color: '#8B9CC8', fontSize: 12 }}>{stretch.benefit}</div>
              </div>
              <div style={{ color: '#39FF14', fontSize: 13, fontWeight: 700, fontFamily: "'Space Mono', monospace" }}>
                {stretch.duration}
              </div>
            </div>
          ))}
        </div>

        {/* Recovery tips */}
        <div style={{ margin: '20px 0 24px', background: 'rgba(57,255,20,0.06)', borderRadius: 18, padding: '18px', border: '1px solid rgba(57,255,20,0.15)' }}>
          <div style={{ color: '#A8F5A0', fontWeight: 700, fontSize: 14, marginBottom: 10 }}>💚 Recovery Tips</div>
          {[
            '🥤 Drink 16–24oz of water in the next 30 min',
            '🍌 Eat a light snack with protein and carbs',
            '😴 Get 7–9 hours of sleep tonight',
            '🛁 A warm bath or shower helps muscle recovery',
          ].map(tip => (
            <div key={tip} style={{ color: '#8B9CC8', fontSize: 13, padding: '6px 0', lineHeight: 1.4, display: 'flex', gap: 4 }}>
              {tip}
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div style={{ padding: '0 24px 48px' }}>
        <button className="btn-accent" onClick={onComplete}>
          🎉 Finish Workout
        </button>
      </div>
    </div>
  )
}
