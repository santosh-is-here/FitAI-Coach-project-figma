import { useState, useEffect, useRef } from 'react'
import Avatar from '../components/Avatar'
import CircularProgress from '../components/CircularProgress'

const exercises = [
  { name: 'Marching in Place', muscle: 'Cardio', sets: 2, reps: '30 sec', tip: 'Keep your core engaged and swing your arms naturally.', icon: '🚶', nextName: 'Arm Circles' },
  { name: 'Arm Circles', muscle: 'Shoulders', sets: 2, reps: '20 reps', tip: 'Keep your shoulders relaxed and movements smooth.', icon: '🔄', nextName: 'Squats' },
  { name: 'Squats', muscle: 'Legs & Glutes', sets: 3, reps: '10 reps', tip: 'Push your knees out, keep your back straight, weight in heels.', icon: '🦵', nextName: 'Wall Push-ups' },
  { name: 'Wall Push-ups', muscle: 'Chest & Arms', sets: 3, reps: '12 reps', tip: 'Keep your body in a straight line from head to heels.', icon: '🤲', nextName: 'Glute Bridge' },
  { name: 'Glute Bridge', muscle: 'Glutes & Core', sets: 3, reps: '15 reps', tip: 'Squeeze your glutes at the top and hold for 1 second.', icon: '🍑', nextName: 'Knee Raises' },
  { name: 'Knee Raises', muscle: 'Core & Hip Flexors', sets: 2, reps: '20 reps', tip: 'Control the movement, don\'t swing your legs.', icon: '🦿', nextName: 'Cool Down' },
]

const quotes = [
  '"You are stronger than you think!"',
  '"Every rep brings you closer to your goal."',
  '"Consistency is the key to results."',
  '"You\'re doing amazing — keep it up!"',
]

type Modal = 'none' | 'too-hard' | 'too-easy' | 'pause'

export default function LiveWorkoutScreen({
  onBreak,
  onPain,
  onComplete,
}: { onBreak: () => void; onPain: () => void; onComplete: () => void }) {
  const [exIdx, setExIdx] = useState(0)
  const [setIdx, setSetIdx] = useState(1)
  const [timer, setTimer] = useState(30)
  const [running, setRunning] = useState(true)
  const [voiceOn, setVoiceOn] = useState(true)
  const [modal, setModal] = useState<Modal>('none')
  const [quoteIdx, setQuoteIdx] = useState(0)
  const [calories, setCalories] = useState(0)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const ex = exercises[exIdx]
  const totalSets = ex.sets
  const progress = Math.round(((exIdx + 1) / exercises.length) * 100)
  const timerMax = 30

  useEffect(() => {
    if (!running) { if (intervalRef.current) clearInterval(intervalRef.current); return }
    intervalRef.current = setInterval(() => {
      setTimer(t => {
        if (t <= 1) {
          setCalories(c => c + 8)
          if (setIdx < totalSets) {
            setSetIdx(s => s + 1)
            return timerMax
          } else {
            if (exIdx < exercises.length - 1) {
              setExIdx(i => i + 1)
              setSetIdx(1)
              setQuoteIdx(q => (q + 1) % quotes.length)
              return timerMax
            } else {
              clearInterval(intervalRef.current!)
              onComplete()
              return 0
            }
          }
        }
        return t - 1
      })
    }, 1000)
    return () => { if (intervalRef.current) clearInterval(intervalRef.current) }
  }, [running, exIdx, setIdx, totalSets])

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`

  if (modal !== 'none') {
    return (
      <div style={{ minHeight: 844, background: 'rgba(0,0,0,0.95)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        {modal === 'too-hard' && (
          <div className="glass" style={{ borderRadius: 28, padding: 28, width: '100%', textAlign: 'center' }}>
            <span style={{ fontSize: 48 }}>💙</span>
            <h2 style={{ color: '#F0F4FF', fontSize: 22, fontWeight: 800, margin: '16px 0 8px' }}>This seems difficult</h2>
            <p style={{ color: '#8B9CC8', fontSize: 14, margin: '0 0 24px', lineHeight: 1.5 }}>
              It's perfectly okay — let's adjust this to work better for you right now.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                { label: '📉 Reduce Difficulty', desc: 'Slower pace, fewer reps' },
                { label: '🔄 Replace Exercise', desc: 'Similar but easier movement' },
                { label: '☕ Short Break', desc: 'Rest for 60 seconds', action: onBreak },
              ].map(({ label, desc, action }) => (
                <button key={label} onClick={() => { setModal('none'); setRunning(true); action?.() }} style={{
                  padding: '16px', borderRadius: 16, background: 'rgba(33,150,243,0.12)',
                  border: '1px solid rgba(33,150,243,0.2)', color: '#F0F4FF', cursor: 'pointer', textAlign: 'left',
                }}>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>{label}</div>
                  <div style={{ color: '#8B9CC8', fontSize: 13, marginTop: 2 }}>{desc}</div>
                </button>
              ))}
              <button className="btn-ghost" onClick={() => { setModal('none'); setRunning(true) }}>
                Continue As Is
              </button>
            </div>
          </div>
        )}
        {modal === 'too-easy' && (
          <div className="glass" style={{ borderRadius: 28, padding: 28, width: '100%', textAlign: 'center' }}>
            <span style={{ fontSize: 48 }}>🔥</span>
            <h2 style={{ color: '#F0F4FF', fontSize: 22, fontWeight: 800, margin: '16px 0 8px' }}>You're crushing it!</h2>
            <p style={{ color: '#8B9CC8', fontSize: 14, margin: '0 0 24px', lineHeight: 1.5 }}>
              You're making great progress! Want to step it up a notch?
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                { label: '📈 Increase Reps', desc: 'Add 5 more reps per set' },
                { label: '💥 Increase Difficulty', desc: 'More challenging variation' },
                { label: '✅ Keep Current', desc: 'Stay at this level' },
              ].map(({ label, desc }) => (
                <button key={label} onClick={() => { setModal('none'); setRunning(true) }} style={{
                  padding: '16px', borderRadius: 16, background: 'rgba(57,255,20,0.08)',
                  border: '1px solid rgba(57,255,20,0.2)', color: '#F0F4FF', cursor: 'pointer', textAlign: 'left',
                }}>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>{label}</div>
                  <div style={{ color: '#8B9CC8', fontSize: 13, marginTop: 2 }}>{desc}</div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <div style={{ minHeight: 844, background: '#080910', display: 'flex', flexDirection: 'column' }}>
      {/* Header controls */}
      <div style={{ padding: '16px 20px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <button onClick={() => { setRunning(false); onBreak() }} style={{ padding: '8px 16px', borderRadius: 100, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)', color: '#8B9CC8', cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>
          ⏸ Pause
        </button>
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: '#8B9CC8', fontSize: 11 }}>WORKOUT</div>
          <div style={{ color: '#39FF14', fontWeight: 700, fontSize: 12 }}>{progress}% complete</div>
        </div>
        <button onClick={() => { setRunning(false); onPain() }} style={{ padding: '8px 16px', borderRadius: 100, background: 'rgba(239,68,68,0.15)', border: '1px solid rgba(239,68,68,0.3)', color: '#FCA5A5', cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>
          🛑 Pain
        </button>
      </div>

      {/* Progress bar */}
      <div style={{ height: 3, background: 'rgba(255,255,255,0.06)', margin: '12px 0 0' }}>
        <div style={{ height: '100%', width: `${progress}%`, background: 'linear-gradient(90deg, #2196F3, #39FF14)', transition: 'width 0.5s ease' }} />
      </div>

      {/* Exercise name & set */}
      <div style={{ padding: '20px 24px 0', textAlign: 'center' }}>
        <div style={{ color: '#8B9CC8', fontSize: 12, letterSpacing: '0.1em', fontWeight: 600, marginBottom: 6 }}>
          EXERCISE {exIdx + 1}/{exercises.length}
        </div>
        <h2 style={{ color: '#F0F4FF', fontSize: 26, fontWeight: 800, margin: '0 0 4px', lineHeight: 1.1 }}>
          {ex.icon} {ex.name}
        </h2>
        <div style={{ color: '#39FF14', fontSize: 14, fontWeight: 700 }}>Set {setIdx} of {totalSets}</div>
      </div>

      {/* Center display */}
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '20px 24px', gap: 20 }}>
        <Avatar mood="encouraging" size={100} />

        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
          <CircularProgress value={timer} max={timerMax} size={110} strokeWidth={8} color="#39FF14" trailColor="rgba(255,255,255,0.06)">
            <div style={{ textAlign: 'center' }}>
              <div style={{ color: '#F0F4FF', fontSize: 26, fontWeight: 800, fontFamily: "'Space Mono', monospace", lineHeight: 1 }}>
                {String(timer).padStart(2, '0')}
              </div>
              <div style={{ color: '#8B9CC8', fontSize: 11 }}>seconds</div>
            </div>
          </CircularProgress>
        </div>
      </div>

      {/* Stats row */}
      <div style={{ display: 'flex', gap: 10, padding: '0 24px', marginBottom: 16 }}>
        {[
          { label: 'Calories', value: calories, unit: 'cal', color: '#F59E0B' },
          { label: 'Heart Rate', value: '~98', unit: 'bpm', color: '#EF4444' },
          { label: 'Muscle', value: ex.muscle.split(' ')[0], unit: '', color: '#2196F3' },
        ].map(({ label, value, unit, color }) => (
          <div key={label} className="glass" style={{ flex: 1, borderRadius: 14, padding: '12px 8px', textAlign: 'center' }}>
            <div style={{ color, fontWeight: 800, fontSize: 16, fontFamily: "'Space Mono', monospace" }}>{value}<span style={{ fontSize: 11 }}>{unit}</span></div>
            <div style={{ color: '#8B9CC8', fontSize: 11, marginTop: 2 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Form tip */}
      <div style={{ margin: '0 24px 12px' }}>
        <div className="glass-blue" style={{ borderRadius: 16, padding: '12px 16px' }}>
          <div style={{ color: '#93C5FD', fontSize: 12, fontWeight: 700, marginBottom: 4 }}>💡 AI FORM TIP</div>
          <p style={{ color: '#C4D4F0', fontSize: 13, margin: 0, lineHeight: 1.5 }}>{ex.tip}</p>
        </div>
      </div>

      {/* Motivational quote */}
      <div style={{ margin: '0 24px 12px' }}>
        <p style={{ color: '#39FF14', fontSize: 13, fontStyle: 'italic', textAlign: 'center', margin: 0, opacity: 0.8 }}>
          {quotes[quoteIdx]}
        </p>
      </div>

      {/* Controls */}
      <div style={{ padding: '0 24px', display: 'flex', gap: 10, marginBottom: 12 }}>
        <button onClick={() => setRunning(r => !r)} style={{
          flex: 1, padding: '14px', borderRadius: 16,
          background: running ? 'rgba(245,158,11,0.15)' : 'rgba(57,255,20,0.15)',
          border: `1px solid ${running ? 'rgba(245,158,11,0.3)' : 'rgba(57,255,20,0.3)'}`,
          color: running ? '#FCD34D' : '#A8F5A0', fontWeight: 700, fontSize: 15, cursor: 'pointer',
        }}>
          {running ? '⏸ Pause' : '▶ Resume'}
        </button>
        <button onClick={() => { if (exIdx < exercises.length - 1) { setExIdx(i => i + 1); setSetIdx(1); setTimer(timerMax) } else onComplete() }} style={{
          flex: 1, padding: '14px', borderRadius: 16,
          background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)',
          color: '#8B9CC8', fontWeight: 700, fontSize: 15, cursor: 'pointer',
        }}>
          Skip ⏭
        </button>
      </div>

      {/* Adaptive buttons */}
      <div style={{ padding: '0 24px 8px', display: 'flex', gap: 10 }}>
        <button onClick={() => { setRunning(false); setModal('too-hard') }} style={{
          flex: 1, padding: '12px', borderRadius: 16,
          background: 'rgba(139,92,246,0.1)', border: '1px solid rgba(139,92,246,0.25)',
          color: '#C4B5FD', fontSize: 13, fontWeight: 600, cursor: 'pointer',
        }}>😓 Too Hard</button>
        <button onClick={() => { setRunning(false); setModal('too-easy') }} style={{
          flex: 1, padding: '12px', borderRadius: 16,
          background: 'rgba(57,255,20,0.08)', border: '1px solid rgba(57,255,20,0.2)',
          color: '#A8F5A0', fontSize: 13, fontWeight: 600, cursor: 'pointer',
        }}>💪 Too Easy</button>
        <button onClick={() => { setRunning(false); setVoiceOn(v => !v) }} style={{
          padding: '12px 16px', borderRadius: 16,
          background: voiceOn ? 'rgba(33,150,243,0.12)' : 'rgba(255,255,255,0.06)',
          border: `1px solid ${voiceOn ? 'rgba(33,150,243,0.25)' : 'rgba(255,255,255,0.08)'}`,
          color: voiceOn ? '#93C5FD' : '#8B9CC8', fontSize: 18, cursor: 'pointer',
        }}>{voiceOn ? '🔊' : '🔇'}</button>
      </div>

      {/* Next exercise */}
      {exIdx < exercises.length - 1 && (
        <div style={{ margin: '8px 24px 24px', padding: '14px', background: 'rgba(255,255,255,0.03)', borderRadius: 14, border: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ color: '#3A4A6B', fontSize: 12, fontWeight: 600 }}>UP NEXT:</div>
          <div style={{ color: '#8B9CC8', fontSize: 13, fontWeight: 600 }}>{ex.nextName}</div>
        </div>
      )}
    </div>
  )
}
