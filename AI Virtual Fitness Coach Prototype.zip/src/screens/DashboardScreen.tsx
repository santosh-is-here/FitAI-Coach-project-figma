import Avatar from '../components/Avatar'
import CircularProgress from '../components/CircularProgress'

const weekDays = ['M', 'T', 'W', 'T', 'F', 'S', 'S']
const weekActivity = [1, 1, 0, 1, 0, 0, 1]

export default function DashboardScreen({ onStartWorkout, onDesignSystem }: { onStartWorkout: () => void; onDesignSystem: () => void }) {
  const today = new Date()
  const dateStr = today.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })

  return (
    <div style={{ minHeight: 844, background: '#080910', overflowY: 'auto' }}>
      {/* Status bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '16px 24px 0', alignItems: 'center' }}>
        <span style={{ color: '#8B9CC8', fontSize: 13, fontFamily: "'Space Mono', monospace" }}>9:41</span>
        <div style={{ display: 'flex', gap: 6 }}>
          <span style={{ color: '#8B9CC8', fontSize: 13 }}>📶 🔋</span>
        </div>
      </div>

      {/* Header */}
      <div style={{
        background: 'radial-gradient(ellipse 80% 50% at 50% 0%, rgba(33,150,243,0.18) 0%, transparent 60%)',
        padding: '16px 24px 24px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          <div>
            <div style={{ color: '#8B9CC8', fontSize: 13 }}>{dateStr}</div>
            <h1 style={{ color: '#F0F4FF', fontSize: 24, fontWeight: 800, margin: '4px 0 0', lineHeight: 1.1 }}>
              Welcome back,<br />
              <span style={{ background: 'linear-gradient(135deg, #2196F3, #39FF14)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                Alex 👋
              </span>
            </h1>
          </div>
          <Avatar mood="happy" size={70} animate={false} />
        </div>

        {/* Today's goal */}
        <div className="glass-blue" style={{ borderRadius: 20, padding: '18px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <div>
              <div style={{ color: '#93C5FD', fontSize: 12, fontWeight: 700, letterSpacing: '0.08em' }}>TODAY'S GOAL</div>
              <div style={{ color: '#F0F4FF', fontWeight: 700, fontSize: 16, marginTop: 2 }}>Full Body Workout</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ color: '#39FF14', fontWeight: 800, fontSize: 22, fontFamily: "'Space Mono', monospace" }}>20</div>
              <div style={{ color: '#8B9CC8', fontSize: 11 }}>minutes</div>
            </div>
          </div>
          <div style={{ height: 6, background: 'rgba(255,255,255,0.08)', borderRadius: 3, marginBottom: 8 }}>
            <div style={{ width: '35%', height: '100%', background: 'linear-gradient(90deg, #2196F3, #39FF14)', borderRadius: 3 }} />
          </div>
          <div style={{ color: '#8B9CC8', fontSize: 12 }}>35% of weekly goal reached</div>
        </div>
      </div>

      {/* Stats cards */}
      <div style={{ padding: '0 24px 20px' }}>
        <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
          {[
            { label: 'Total Workouts', value: '4', unit: 'this week', color: '#2196F3', icon: '💪' },
            { label: 'Calories Burned', value: '648', unit: 'kcal', color: '#F59E0B', icon: '🔥' },
          ].map(({ label, value, unit, color, icon }) => (
            <div key={label} className="glass" style={{ flex: 1, borderRadius: 20, padding: '18px 16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <span style={{ fontSize: 24 }}>{icon}</span>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: color }} />
              </div>
              <div style={{ color, fontSize: 28, fontWeight: 800, fontFamily: "'Space Mono', monospace" }}>{value}</div>
              <div style={{ color: '#8B9CC8', fontSize: 12 }}>{label}</div>
              <div style={{ color: '#3A4A6B', fontSize: 11 }}>{unit}</div>
            </div>
          ))}
        </div>

        {/* Weekly progress */}
        <div className="glass" style={{ borderRadius: 20, padding: '20px', marginBottom: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div style={{ color: '#F0F4FF', fontWeight: 700, fontSize: 15 }}>Weekly Progress</div>
            <div style={{ color: '#39FF14', fontSize: 13, fontWeight: 700 }}>4/5 goal</div>
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
            {weekDays.map((day, i) => (
              <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                <div style={{
                  width: 36, height: 48, borderRadius: 10,
                  background: weekActivity[i] ? 'rgba(57,255,20,0.2)' : 'rgba(255,255,255,0.04)',
                  border: weekActivity[i] ? '1px solid rgba(57,255,20,0.4)' : '1px solid rgba(255,255,255,0.08)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 16,
                }}>
                  {weekActivity[i] ? '✅' : ''}
                </div>
                <span style={{ color: '#8B9CC8', fontSize: 11 }}>{day}</span>
              </div>
            ))}
          </div>
        </div>

        {/* AI Recommendations */}
        <div style={{ marginBottom: 20 }}>
          <h3 style={{ color: '#F0F4FF', fontSize: 16, fontWeight: 700, margin: '0 0 14px' }}>🤖 AI Recommendations</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              { title: 'Upper Body Focus', desc: 'Based on your progress, try targeting arms and shoulders next.', icon: '💪', badge: 'Recommended' },
              { title: 'Rest Day', desc: 'Your body has been active 4 days — a light walk today could help recovery.', icon: '😴', badge: 'Rest' },
              { title: 'Stretch Routine', desc: '10 min of evening stretching to improve your flexibility score.', icon: '🧘', badge: 'New' },
            ].map(({ title, desc, icon, badge }) => (
              <div key={title} className="glass" style={{ borderRadius: 16, padding: '14px 18px', display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: 'rgba(33,150,243,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>
                  {icon}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                    <span style={{ color: '#F0F4FF', fontWeight: 700, fontSize: 14 }}>{title}</span>
                    <span style={{ background: 'rgba(33,150,243,0.15)', color: '#93C5FD', fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 100, border: '1px solid rgba(33,150,243,0.2)' }}>{badge}</span>
                  </div>
                  <p style={{ color: '#8B9CC8', fontSize: 12, margin: 0, lineHeight: 1.4 }}>{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* History */}
        <div style={{ marginBottom: 20 }}>
          <h3 style={{ color: '#F0F4FF', fontSize: 16, fontWeight: 700, margin: '0 0 14px' }}>Recent Workouts</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              { name: 'Full Body Beginner', date: 'Today', duration: '21 min', cal: 162, icon: '💪' },
              { name: 'Upper Body Focus', date: 'Yesterday', duration: '18 min', cal: 140, icon: '🏋️' },
              { name: 'Core & Flexibility', date: '2 days ago', duration: '15 min', cal: 110, icon: '🧘' },
            ].map(({ name, date, duration, cal, icon }) => (
              <div key={name} className="glass" style={{ borderRadius: 14, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14 }}>
                <div style={{ width: 44, height: 44, borderRadius: 14, background: 'rgba(33,150,243,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>
                  {icon}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ color: '#F0F4FF', fontWeight: 600, fontSize: 14 }}>{name}</div>
                  <div style={{ color: '#8B9CC8', fontSize: 12 }}>{date} · {duration}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ color: '#F59E0B', fontWeight: 700, fontSize: 14 }}>{cal}</div>
                  <div style={{ color: '#3A4A6B', fontSize: 11 }}>cal</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Design System link */}
        <button onClick={onDesignSystem} style={{
          width: '100%', padding: '14px', borderRadius: 14,
          background: 'rgba(255,255,255,0.03)', border: '1px dashed rgba(255,255,255,0.1)',
          color: '#3A4A6B', fontSize: 13, fontWeight: 600, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          marginBottom: 8,
        }}>
          🎨 View Design System →
        </button>
      </div>

      {/* Bottom CTA */}
      <div style={{ padding: '0 24px 48px' }}>
        <button className="btn-accent animate-glow" onClick={onStartWorkout}>
          ⚡ Start Today's Workout
        </button>
      </div>
    </div>
  )
}
